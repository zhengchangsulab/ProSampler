#include<iostream>
#include<fstream>
#include<string>
#include<string.h>
#include<stdlib.h>
#include<stdint.h>
#include<vector>
#include<map>

using namespace std;

#define SIZE 4


int f_in_id, f_bg_id, flag;
typedef map<string,double> map_string;

/****************************************************************************
 *
 * Construct the random number generator based on Mersenne Twister algorithm
 *
 ****************************************************************************/

/* Period parameters */  
#define N 624
#define M 397
#define MATRIX_A 0x9908b0dfUL   /* constant vector a */
#define UPPER_MASK 0x80000000UL /* most significant w-r bits */
#define LOWER_MASK 0x7fffffffUL /* least significant r bits */

static unsigned long mt[N]; /* the array for the state vector  */
static int mti=N+1; /* mti==N+1 means mt[N] is not initialized */

/* initializes mt[N] with a seed */
void init_genrand(unsigned long s)
{
    mt[0]= s & 0xffffffffUL;
    for (mti=1; mti<N; mti++) {
        mt[mti] = 
		(1812433253UL * (mt[mti-1] ^ (mt[mti-1] >> 30)) + mti); 
        /* See Knuth TAOCP Vol2. 3rd Ed. P.106 for multiplier. */
        /* In the previous versions, MSBs of the seed affect   */
        /* only MSBs of the array mt[].                        */
        /* 2002/01/09 modified by Makoto Matsumoto             */
        mt[mti] &= 0xffffffffUL;
        /* for >32 bit machines */
    }
}

/* initialize by an array with array-length */
/* init_key is the array for initializing keys */
/* key_length is its length */
/* slight change for C++, 2004/2/26 */
void init_by_array(unsigned long init_key[], int key_length)
{
    int i, j, k;
    init_genrand(19650218UL);
    i=1; j=0;
    k = (N>key_length ? N : key_length);
    for (; k; k--) {
        mt[i] = (mt[i] ^ ((mt[i-1] ^ (mt[i-1] >> 30)) * 1664525UL))
		+ init_key[j] + j; /* non linear */
        mt[i] &= 0xffffffffUL; /* for WORDSIZE > 32 machines */
        i++; j++;
        if (i>=N) { mt[0] = mt[N-1]; i=1; }
        if (j>=key_length) j=0;
    }
    for (k=N-1; k; k--) {
        mt[i] = (mt[i] ^ ((mt[i-1] ^ (mt[i-1] >> 30)) * 1566083941UL))
		- i; /* non linear */
        mt[i] &= 0xffffffffUL; /* for WORDSIZE > 32 machines */
        i++;
        if (i>=N) { mt[0] = mt[N-1]; i=1; }
    }
	
    mt[0] = 0x80000000UL; /* MSB is 1; assuring non-zero initial array */ 
}

/* generates a random number on [0,0xffffffff]-interval */
uint32_t genrand_int32(void) {
	unsigned long y;
	static unsigned long mag01[2]={0x0UL, MATRIX_A};
	/* mag01[x] = x * MATRIX_A  for x=0,1 */
	
	if (mti >= N) { /* generate N words at one time */
		int kk;
		
		if (mti == N+1)   /* if init_genrand() has not been called, */
			init_genrand(5489UL); /* a default initial seed is used */
		
		for (kk=0;kk<N-M;kk++) {
			y = (mt[kk]&UPPER_MASK)|(mt[kk+1]&LOWER_MASK);
			mt[kk] = mt[kk+M] ^ (y >> 1) ^ mag01[y & 0x1UL];
		}
		for (;kk<N-1;kk++) {
			y = (mt[kk]&UPPER_MASK)|(mt[kk+1]&LOWER_MASK);
			mt[kk] = mt[kk+(M-N)] ^ (y >> 1) ^ mag01[y & 0x1UL];
		}
		y = (mt[N-1]&UPPER_MASK)|(mt[0]&LOWER_MASK);
		mt[N-1] = mt[M-1] ^ (y >> 1) ^ mag01[y & 0x1UL];
		
		mti = 0;
	}
	
	y = mt[mti++];
	
	/* Tempering */
	y ^= (y >> 11);
	y ^= (y << 7) & 0x9d2c5680UL;
	y ^= (y << 15) & 0xefc60000UL;
	y ^= (y >> 18);
	
	return y;
}

uint64_t genrand_int64(void) {
	uint64_t x, y;
	
	x = genrand_int32(); y = genrand_int32();
	return (x<<32)|y;
}

void init_mersenne(void) {
	unsigned long init[4]={0x123, 0x234, 0x345, 0x456}, length=4;
	init_by_array(init, length);
}

double genrand_real2(void)
{
	return genrand_int64()*(1.0/(4294967296.0*4294967296.0)); 
}

double ranf(void)
{    
	init_genrand((unsigned)time(NULL)+rand());
	return (genrand_real2());
}

double genunf(double low,double high)
{
	static double genunf;
    genunf = low+(high-low)*ranf(); 
	
    return genunf;
}

/****************************************************************************
 *
 * Function: partition
 * 1. Used in quickSort algorithm
 *
 ****************************************************************************/

int partition(double a[], int start, int stop, int id[])
{
	int temp_id, up=start, down=stop-1;
	double temp_value, part=a[stop];
	if(stop<=start) return start;
	
	while(true)
	{
		while(a[up]<part) up++;
		while(part<a[down] && (up<down)) down--;
		
		if(up>=down) break;
		
		temp_value=a[up];  a[up]=a[down]; a[down]=temp_value;
		temp_id=id[up]; id[up]=id[down]; id[down]=temp_id;
		
		up++; down--;
	}
	
	temp_value=a[up]; a[up]=a[stop]; a[stop]=temp_value;
	temp_id=id[up]; id[up]=id[stop]; id[stop]=temp_id;
	return up;
}

/****************************************************************************
 *
 * Function: quickSort
 * 1. Sort the integers saved in an array in increasing order
 * 2. Call the function partition
 *
 ****************************************************************************/

void quickSort(double a[], int start, int stop, int id[])
{
	int i;
	if(stop<=start) return;
	
	i=partition(a,start,stop,id); 
	quickSort(a,start,i-1,id);
	quickSort(a,i+1,stop,id);
}

/****************************************************************************
 *
 * Function: genmulone
 * 1. Generate a random variable following the multinomial distribution
 *
 ****************************************************************************/

int genmulone(double *p_input,long ncat)
{
	int i;
	double *p = NULL;
	p = new double [ncat];
	for(i=0;i<ncat;i++) p[i]=p_input[i];
	
	int*q = NULL;
	q = new int [ncat];
	for(i=0;i<ncat;i++) q[i]=i;
	
	quickSort(p, 0, ncat-1, q);
	
	double prob=genunf(0,1);
	int outcome=ncat-1;
	while (outcome>=0  && prob > p[outcome])
	{
		prob -= p[outcome];
		outcome--;
	}
	
	return q[outcome];
}

/******************************************************************************************************
 *
 * Function: main function
 * 1. Read into input sequences in FASTA format
 * 2. Output the background sequence file
 * 3. Usage: ./markov -i f_in -b f_bg -f flag
 * 4. f_in: the file path of the input file
 * 5. f_bg: the file path of the background file
 * 6. flag: the order of the Markov Model (3 as default)
 *
 ******************************************************************************************************/

int main(int argc, char **argv)
{
	int i,j;

	if(argc<5)
	{
		cout<<"Usage: ./markov -i f_in -b f_bg -f flag"<<endl;
		cout<<"================================================================================"<<endl;
		cout<<"f_in: the file path of the input file"<<endl;
		cout<<"f_bg: the file path of the background file"<<endl;
		cout<<"flag: the order of the Markov Model (3 as default)"<<endl;
		cout<<"================================================================================"<<endl;
		exit(0);
	}

	flag=3;
	for(i=1;i<argc-1;i++)
	{
		if(strcmp(argv[i], "-i")==0) {f_in_id=i+1;i++;}
		else if(strcmp(argv[i], "-b")==0) {f_bg_id=i+1; i++;}
		else if(strcmp(argv[i], "-f")==0) {flag=atoi(argv[i+1]);i++;}
	}

/******************************************************************************************************
 *
 * Count the number of input sequences
 *
 ******************************************************************************************************/

	string str;	// the string used to contain the input lines
	ifstream f_in_op(argv[f_in_id]);
	if(!f_in_op)
	{
		cerr<<"Error: Can't open the input file! Please check the input parameters again!"<<endl;
		exit(0);
	}

	vector<string> f_in;

	while(!f_in_op.eof())
	{
		getline(f_in_op, str);
		if(str[0]=='>')
		{
			continue;
		}

		if(!str.empty())
		{
			f_in.push_back(str);
		}
	}
	f_in_op.close();

	cout<<"The number of sequences is: "<<f_in.size()<<endl;

/******************************************************************************************************
 *
 * Transform all the lower-case letters to upper-case ones
 *
 ******************************************************************************************************/

	for(i=0;i<f_in.size();i++)
	{
		for(j=0;j<f_in[i].size();j++)
		{
			if(f_in[i][j]>='a' && f_in[i][j]<='z')
			{
				f_in[i][j]='A'+(f_in[i][j]-'a');
			}
		}
	}

/******************************************************************************************************
 *
 * Construct the hash table for various k-mers (k=1, 2, 3, 4)
 *
 ******************************************************************************************************/

	char* alphabet;	// the alphabet for DNA nucleotides A, C, G, T
	alphabet=new char [SIZE];

	alphabet[0]='A';
	alphabet[1]='C';
	alphabet[2]='G';
	alphabet[3]='T';

	map_string hash_onebase, hash_twobase, hash_threebase, hash_fourbase;

	if(flag==0 || flag==1 || flag==2 || flag==3)
	{
		string onebase;	// the string to contain A, C, G, T

		for(i=0;i<SIZE;i++)
		{
			onebase.clear();
			onebase.push_back(alphabet[i]);
			hash_onebase[onebase]=0;
		}	// initialization for the hash table
	}
	else
	{
		cerr<<"Error: The input flag parameter is wrong! Please check it again!"<<endl;
		exit(0);
	}
	
	if(flag==1 || flag==2 || flag==3)
	{
		string twobase;

		for(i=0;i<SIZE;i++)
		{
			for(j=0;j<SIZE;j++)
			{
				twobase.clear();
				twobase.push_back(alphabet[i]);
				twobase.push_back(alphabet[j]);
				hash_twobase[twobase]=0;
			}
		}	// initialization for the hash table
	}
	
	if(flag==2 || flag==3)
	{
		string threebase;

		int k;
		for(i=0;i<SIZE;i++)
		{
			for(j=0;j<SIZE;j++)
			{
				for(k=0;k<SIZE;k++)
				{
					threebase.clear();
					threebase.push_back(alphabet[i]);
					threebase.push_back(alphabet[j]);
					threebase.push_back(alphabet[k]);
					hash_threebase[threebase]=0;
				}
			}
		}	// initialization for the hash table
	}
	
	if(flag==3)
	{
		string fourbase;

		int k, l;
		for(i=0;i<SIZE;i++)
		{
			for(j=0;j<SIZE;j++)
			{
				for(k=0;k<SIZE;k++)
				{
					for(l=0;l<SIZE;l++)
					{
						fourbase.clear();
						fourbase.push_back(alphabet[i]);
						fourbase.push_back(alphabet[j]);
						fourbase.push_back(alphabet[k]);
						fourbase.push_back(alphabet[l]);
						hash_fourbase[fourbase]=0;
					}
				}
			}
		}
	}

/******************************************************************************************************
 *
 * Count the occurrence numbers of various k-mers (k=1, 2, 3, 4)
 *
 ******************************************************************************************************/

	if(flag==0)
	{
		for(i=0;i<f_in.size();i++)
		{
			for(j=0;j<f_in[i].size();j++)
			{
				if(f_in[i][j]!='N')
				{
					hash_onebase[f_in[i].substr(j,1)]++;
				}
			}
		}
	}
	else if(flag==1)
	{
		for(i=0;i<f_in.size();i++)
		{
			for(j=0;j<f_in[i].size();j++)
			{
				if(f_in[i][j]!='N')
				{
					hash_onebase[f_in[i].substr(j,1)]++;
				}

				if(j<f_in[i].size()-1 && f_in[i].substr(j,2).find('N')==f_in[i].substr(j,2).npos)
				{
					hash_twobase[f_in[i].substr(j,2)]++;
				}
			}
		}
	}
	else if(flag==2)
	{
		for(i=0;i<f_in.size();i++)
		{
			for(j=0;j<f_in[i].size();j++)
			{
				if(f_in[i][j]!='N')
				{
					hash_onebase[f_in[i].substr(j,1)]++;
				}

				if(j<f_in[i].size()-1 && f_in[i].substr(j,2).find('N')==f_in[i].substr(j,2).npos)
				{
					hash_twobase[f_in[i].substr(j,2)]++;
				}

				if(j<f_in[i].size()-2 && f_in[i].substr(j,3).find('N')==f_in[i].substr(j,3).npos)
				{
					hash_threebase[f_in[i].substr(j,3)]++;
				}
			}
		}
	}
	else if(flag==3)
	{
		for(i=0;i<f_in.size();i++)
		{
			for(j=0;j<f_in[i].size();j++)
			{
				if(f_in[i][j]!='N')
				{
					hash_onebase[f_in[i].substr(j,1)]++;
				}
				if(j<f_in[i].size()-1 && f_in[i].substr(j,2).find('N')==f_in[i].substr(j,2).npos)
				{
					hash_twobase[f_in[i].substr(j,2)]++;
				}

				if(j<f_in[i].size()-2 && f_in[i].substr(j,3).find('N')==f_in[i].substr(j,3).npos)
				{
					hash_threebase[f_in[i].substr(j,3)]++;
				}

				if(j<f_in[i].size()-3 && f_in[i].substr(j,4).find('N')==f_in[i].substr(j,4).npos)
				{
					hash_fourbase[f_in[i].substr(j,4)]++;
				}
			}
		}
	}

	cout<<"k-mer counting has been completed."<<endl;

/******************************************************************************************************
 *
 * Transform k-mer occurrences into k-mer frequencies (k=0, 1, 2, 3)
 *
 ******************************************************************************************************/

	map<string, double>::iterator iter;
	double sum=0;	// the sum of all nucleotides in sequences

	if(flag==3)
	{
		for(iter=hash_fourbase.begin();iter!=hash_fourbase.end();iter++)
		{
			iter->second/=hash_threebase[iter->first.substr(0,3)];
		}

		for(iter=hash_threebase.begin();iter!=hash_threebase.end();iter++)
		{
			iter->second/=hash_twobase[iter->first.substr(0,2)];
		}

		for(iter=hash_twobase.begin();iter!=hash_twobase.end();iter++)
		{
			iter->second/=hash_onebase[iter->first.substr(0,1)];
		}

		for(iter=hash_onebase.begin();iter!=hash_onebase.end();iter++)
		{
			sum+=iter->second;
		}

		for(iter=hash_onebase.begin();iter!=hash_onebase.end();iter++)
		{
			iter->second/=sum;
		}
	}
	else if(flag==2)
	{
		for(iter=hash_threebase.begin();iter!=hash_threebase.end();iter++)
		{
			iter->second/=hash_twobase[iter->first.substr(0,2)];
		}

		for(iter=hash_twobase.begin();iter!=hash_twobase.end();iter++)
		{
			iter->second/=hash_onebase[iter->first.substr(0,1)];
		}

		for(iter=hash_onebase.begin();iter!=hash_onebase.end();iter++)
		{
			sum+=iter->second;
		}

		for(iter=hash_onebase.begin();iter!=hash_onebase.end();iter++)
		{
			iter->second/=sum;
		}
	}
	else if(flag==1)
	{
		for(iter=hash_twobase.begin();iter!=hash_twobase.end();iter++)
		{
			iter->second/=hash_onebase[iter->first.substr(0,1)];
		}

		for(iter=hash_onebase.begin();iter!=hash_onebase.end();iter++)
		{
			sum+=iter->second;
		}

		for(iter=hash_onebase.begin();iter!=hash_onebase.end();iter++)
		{
			iter->second/=sum;
		}
	}
	else if(flag==0)
	{
		for(iter=hash_onebase.begin();iter!=hash_onebase.end();iter++)
		{
			sum+=iter->second;
		}

		for(iter=hash_onebase.begin();iter!=hash_onebase.end();iter++)
		{
			iter->second/=sum;
		}
	}

/******************************************************************************************************
 *
 * Generate the simulated sequences with the same number and lengths
 *
 ******************************************************************************************************/

	char** f_bg;	// the array to hold the simulated sequences
	f_bg=new char* [f_in.size()];
	for(i=0;i<f_in.size();i++)
	{
		f_bg[i]=new char [f_in[i].size()];
	}

	double* values0, *values1, *values2, *values3;
	values0=new double [SIZE];
	values1=new double [SIZE];
	values2=new double [SIZE];
	values3=new double [SIZE];
	string tempstr;

	int k;
	if(flag==0)
	{
		for(i=0;i<SIZE;i++)
		{
			tempstr.clear();
			tempstr.push_back(alphabet[i]);
			values0[i]=hash_onebase[tempstr];
		}
		for(i=0;i<f_in.size();i++)
		{
			for(j=0;j<f_in[i].size();j++)
			{
				f_bg[i][j]=alphabet[genmulone(values0,SIZE)];
			}
		}
	}
	else if(flag==1)
	{
		for(i=0;i<SIZE;i++)
		{
			tempstr.clear();
			tempstr.push_back(alphabet[i]);
			values0[i]=hash_onebase[tempstr];
		}
		for(i=0;i<f_in.size();i++)
		{
			f_bg[i][0]=alphabet[genmulone(values0,SIZE)];

			for(j=1;j<f_in[i].size();j++)
			{
				for(k=0;k<SIZE;k++)
				{
					tempstr.clear();
					tempstr.push_back(f_bg[i][j-1]);
					tempstr.push_back(alphabet[k]);
					values1[k]=hash_twobase[tempstr];
				}
				f_bg[i][j]=alphabet[genmulone(values1,SIZE)];
			}
		}
	}
	else if(flag==2)
	{
		for(i=0;i<SIZE;i++)
		{
			tempstr.clear();
			tempstr.push_back(alphabet[i]);
			values0[i]=hash_onebase[tempstr];
		}
		for(i=0;i<f_in.size();i++)
		{
			f_bg[i][0]=alphabet[genmulone(values0,SIZE)];
			for(k=0;k<SIZE;k++)
			{
				tempstr.clear();
				tempstr.push_back(f_bg[i][0]);
				tempstr.push_back(alphabet[k]);
				values1[k]=hash_twobase[tempstr];
			}
			f_bg[i][1]=alphabet[genmulone(values1,SIZE)];

			for(j=2;j<f_in[i].size();j++)
			{
				tempstr.clear();
				tempstr.push_back(f_bg[i][j-2]);
				tempstr.push_back(f_bg[i][j-1]);
				for(k=0;k<SIZE;k++)
				{
					tempstr.push_back(alphabet[k]);
					values2[k]=hash_threebase[tempstr];
				}
				f_bg[i][j]=alphabet[genmulone(values2,SIZE)];
			}
		}
	}
	else if(flag==3)
	{
		for(i=0;i<SIZE;i++)
		{
			tempstr.clear();
			tempstr.push_back(alphabet[i]);
			values0[i]=hash_onebase[tempstr];
		}
		for(i=0;i<f_in.size();i++)
		{
			f_bg[i][0]=alphabet[genmulone(values0,SIZE)];
			for(k=0;k<SIZE;k++)
			{
				tempstr.clear();
				tempstr.push_back(f_bg[i][0]);
				tempstr.push_back(alphabet[k]);
				values1[k]=hash_twobase[tempstr];
			}
			f_bg[i][1]=alphabet[genmulone(values1,SIZE)];

			for(k=0;k<SIZE;k++)
			{
				tempstr.clear();
				tempstr.push_back(f_bg[i][0]);
				tempstr.push_back(f_bg[i][1]);
				tempstr.push_back(alphabet[k]);
				values2[k]=hash_twobase[tempstr];
			}
			f_bg[i][2]=alphabet[genmulone(values2,SIZE)];

			for(j=3;j<f_in[i].size();j++)
			{
				for(k=0;k<SIZE;k++)
				{
					tempstr.clear();
					tempstr.push_back(f_bg[i][j-3]);
					tempstr.push_back(f_bg[i][j-2]);
					tempstr.push_back(f_bg[i][j-1]);
					tempstr.push_back(alphabet[k]);
					values3[k]=hash_fourbase[tempstr];
				}
				f_bg[i][j]=alphabet[genmulone(values3,SIZE)];
			}
		}
	}

	cout<<"Generating the simulated sequences ........"<<endl;

/******************************************************************************************************
 *
 * Generate the simulated sequences
 *
 ******************************************************************************************************/

	ofstream f_bg_op(argv[f_bg_id]);

	for(i=0;i<f_in.size();i++)
	{
		f_bg_op<<">_RandSeq_"<<i<<endl;

		for(j=0;j<f_in[i].size();j++)
		{
			f_bg_op<<f_bg[i][j];
		}
		f_bg_op<<endl;
	}

	f_bg_op.close();

	cout<<"Task finished."<<endl;

	return 0;
}
