/****************************************************************************
 *                                                                          *
 *                                 Head files                               *
 *                                                                          *
 ****************************************************************************/

#include<iostream> // standard input and output stream
#include<fstream> // file input and output stream
#include<string> // C++ string class
#include<string.h> // C string class
#include<stdlib.h> // a C class containing many basic functions for variable transformation
#include<stdint.h> // a C class containing many macros regarding integers
#include<vector> // vector class
#include<stack>// stack class
#include<map> // hash table class
#include<sstream> // stream to segment strings

using namespace std;


/****************************************************************************
 *                                                                          *
 *                      Macros and complex classes                          *
 *                                                                          *
 ****************************************************************************/

#define SIZE 4 // the size of alphabet, i.e., ACGT

typedef struct
{
	vector<string> name; // introduction information of sequencecs
	vector<string> strand; // the ACGT sequences of a dataset
} sequence; // DNA sequence struct

typedef map<string, float> map_string; // a hash table to map strings to float numbers, i.e., k-mers to frequencies

struct kmer_package {
    map_string AA; // one base frequencies
    map_string B; // two base frequencies
    map_string C; // three base frequencies
    map_string D; // four base frequencies
    //map_string T; // four base frequencies
}; // transition martrices used to define Markov chain model


/****************************************************************************
 *                                                                          *
 *                                 Functions                                *
 *                                                                          *
 ****************************************************************************/

// Generate a random float number in a range uniformly
float genunf(float low, float high)
{
	float random = ((float) rand()) / (float) RAND_MAX; // generate a random number without bounds
    float diff = high - low; // set the range of random numbers
    float r = random * diff; // zoom in the random number
    return low + r; // added to the lower bound
}


// Partition a vector of numbers into two sets without random sizes
// after partition, numbers in the first set are smaller than the second set
// this is a divide-and-conpueror approach for quickSort
template <class T> // T can be int, float, or double
int partition(T a[], int start, int stop, int id[])
{
        int temp_id, up = start, down = stop - 1;
        T temp_value, part = a[stop];
        if(stop <= start) return start;

        while (true)
        {    
                while(a[up] < part) up ++;
                while(part < a[down] && (up < down)) down --;

                if(up >= down) break;

                temp_value = a[up];  a[up] = a[down]; a[down] = temp_value;
                temp_id = id[up]; id[up] = id[down]; id[down] = temp_id;

                up ++; down --;
        }    

        temp_value = a[up]; a[up] = a[stop]; a[stop] = temp_value;
        temp_id = id[up]; id[up] = id[stop]; id[stop] = temp_id;
        return up;
}


// This is the fastest algorithm for sorting in implementation
template <class T>
void quickSort(T a[], int start, int stop, int id[])
{
        int i;
        if (stop <= start) return;

        i = partition(a, start, stop, id);
        quickSort(a,start,i - 1, id);
        quickSort(a, i + 1, stop, id);
}


// Generate a random number according to a distribution saved in an array
int genmulone(float *p_input, long ncat)
{
	vector<float> vecp;
	float sum_n=0;
	int i;
	float *p = NULL;
	p = new float [ncat];
	for (i = 0; i < ncat; i ++) {p[i] = p_input[i]; vecp.push_back(p[i]);sum_n+=p[i];}

	
	int*q = NULL;
	q = new int [ncat];
	for (i = 0; i < ncat;i ++) q[i] = i;
	
	quickSort(p, 0, ncat - 1, q);
	
	float prob = genunf(0, 1);
	int outcome = ncat - 1;
	while (outcome >= 0  && prob > p[outcome])
	{
		prob -= p[outcome];
		outcome --;
	}
	if(outcome<0)
	{
		outcome=0;
	}
	
	return q[outcome];
}


// Genrate Markov Chain model
// input the experiment sequences, file path to save the background sequences, and the order 
// of Markov Chain model
// output the Markov Chain transition matrices saved in kmer_package object
struct kmer_package markov(sequence& f_in, sequence& f_bg, int flag = 3)
{
  // Construct the hash table for various k-mers (k = 1, 2, 3, 4)
	char* alphabet;	// the alphabet for DNA nucleotides A, C, G, T
	alphabet = new char [SIZE];

	alphabet[0]='A';
	alphabet[1]='C';
	alphabet[2]='G';
	alphabet[3]='T';

	map_string hash_onebase, hash_twobase, hash_threebase, hash_fourbase;
	// hash tables to correspond k-mers (k = 1, 2, 3, and 4) to their frequencies

	if (flag == 0 || flag == 1 || flag == 2 || flag == 3) // the flag parameter is correctly input
	{
		string onebase;	// the string to contain A, C, G, T

	  // Initialization of the hash table by zeros
		for (int i = 0; i < SIZE; i ++)
		{
			onebase.clear();
			onebase.push_back(alphabet[i]);
			hash_onebase[onebase] = 0;
		}	
	}
	else
	{
		cerr << "Error: The input flag parameter is wrong! Please check it again!\n";
		exit(0);
	}
	
	// The order is larger than 0
	if (flag == 1 || flag == 2 || flag == 3)
	{
		string twobase;

	  // initialization for the hash table of 2-mers
		for (int i = 0; i < SIZE; i ++)
		{
			for (int j = 0; j < SIZE; j ++)
			{
				twobase.clear();
				twobase.push_back(alphabet[i]);
				twobase.push_back(alphabet[j]);
				hash_twobase[twobase] = 0;
			}
		}
	}
	
	// The order is larger than 1
	if (flag == 2 || flag == 3)
	{
		string threebase;

	  // initialization for the hash table of 3-mers
		for (int i = 0; i < SIZE; i ++)
		{
			for (int j = 0; j < SIZE; j ++)
			{
				for (int k = 0; k < SIZE; k ++)
				{
					threebase.clear();
					threebase.push_back(alphabet[i]);
					threebase.push_back(alphabet[j]);
					threebase.push_back(alphabet[k]);
					hash_threebase[threebase] = 0;
				}
			}
		}
	}
	
	// The order is larger than 2
	if (flag == 3)
	{
		string fourbase;

	  // Initialization for the hash table of 4-mers
		for (int i = 0; i < SIZE; i ++)
		{
			for (int j = 0; j < SIZE; j ++)
			{
				for (int k = 0; k < SIZE; k ++)
				{
					for (int l = 0; l < SIZE; l ++)
					{
						fourbase.clear();
						fourbase.push_back(alphabet[i]);
						fourbase.push_back(alphabet[j]);
						fourbase.push_back(alphabet[k]);
						fourbase.push_back(alphabet[l]);
						hash_fourbase[fourbase] = 0;
					}
				}
			}
		}
	}

	// End
	
	
	
	

	// Count the frequencies of k-mers (k = 0, 1, 2, and 3)
	if (flag == 0)
	{
		for (int i = 0; i < f_in.strand.size(); i ++) // for each sequence
		{
			for (int j = 0; j < f_in.strand[i].size(); j ++) // for each nucleotide in a sequence
			{
				if (f_in.strand[i][j] != 'N') // not "N"
				{
					hash_onebase[f_in.strand[i].substr(j, 1)] ++; // 1-mers
				}
			}
		}
	}
	else if (flag == 1)
	{
		for (int i = 0; i < f_in.strand.size(); i ++)
		{
			for (int j = 0; j < f_in.strand[i].size(); j ++)
			{
				if (f_in.strand[i][j] != 'N') // not 'N'
				{
					hash_onebase[f_in.strand[i].substr(j, 1)] ++; // 1-mers
				}

				if (j < f_in.strand[i].size() - 1 && f_in.strand[i].substr(j, 2).find('N') 
						== f_in.strand[i].substr(j, 2).npos) // no 'N' is included
				{
					hash_twobase[f_in.strand[i].substr(j, 2)] ++; // 2-mers
				}
			}
		}
	}
	else if (flag == 2)
	{
		for (int i = 0; i < f_in.strand.size(); i ++)
		{
			for (int j = 0; j < f_in.strand[i].size(); j ++)
			{
				if (f_in.strand[i][j] != 'N') // not 'N'
				{
					hash_onebase[f_in.strand[i].substr(j, 1)] ++; // 1-mers
				}

				if (j < f_in.strand[i].size() - 1 && f_in.strand[i].substr(j, 2).find('N') 
						== f_in.strand[i].substr(j, 2).npos) // no 'N' is included
				{
					hash_twobase[f_in.strand[i].substr(j, 2)] ++; // 2-mers
				}

				if (j < f_in.strand[i].size() - 2 && f_in.strand[i].substr(j, 3).find('N') 
						== f_in.strand[i].substr(j, 3).npos) // no 'N' is included
				{
					hash_threebase[f_in.strand[i].substr(j, 3)] ++; // 3-mers
				}
			}
		}
	}
	else if (flag == 3)
	{
		for (int i = 0; i < f_in.strand.size(); i ++)
		{
			for (int j = 0; j < f_in.strand[i].size(); j ++)
			{
				if (f_in.strand[i][j] != 'N') // not 'N'
				{
					hash_onebase[f_in.strand[i].substr(j, 1)] ++; // 1-mers
				}
				if (j < f_in.strand[i].size() - 1 && f_in.strand[i].substr(j, 2).find('N') 
						== f_in.strand[i].substr(j, 2).npos) // no 'N' is included
				{
					hash_twobase[f_in.strand[i].substr(j, 2)] ++; // 2-mers
				}

				if (j < f_in.strand[i].size() - 2 && f_in.strand[i].substr(j, 3).find('N') 
						== f_in.strand[i].substr(j, 3).npos) // no 'N' is included
				{
					hash_threebase[f_in.strand[i].substr(j,3)] ++; // 3-mers
				}

				if (j < f_in.strand[i].size() - 3 && f_in.strand[i].substr(j, 4).find('N') 
						== f_in.strand[i].substr(j, 4).npos) // no 'N' is included
				{
					hash_fourbase[f_in.strand[i].substr(j, 4)] ++; // 4-mers
				}
			}
		}
	}

	cout << "k-mer counting has been completed.\n";

	// End

	
	
	

	// Build the transition matrices
	map<string, float>::iterator iter; // an iterator to traverse a hash table
    map<string, float>::iterator iter1;
	float sum0 = 0;	// the sum of all nucleotides in sequences
	int count=0;
	int flag2=0;
	int sum;

	//map_string threebase_freq = hash_threebase; // make a copy of the hash table of 3-mers
	if (flag == 3)
	{
		iter1=hash_fourbase.begin();
		flag2=0;
	  // Normalize the 4-mers by dividing their prefix 3-mers
		for (iter = hash_fourbase.begin(); iter != hash_fourbase.end(); iter ++)
		{
			if(flag2%4==0)
			{
				sum=0;
				for (int flag1=0; flag1 < 4; flag1++)
				{					
					sum+=iter1->second;
					iter1++;
				}
				iter->second /= sum;
			}
			else
			{
				iter->second /= sum;
			}
			flag2++;
			//iter->second /= hash_threebase[iter->first.substr(0, 3)]; // divide the occurrence of 
			// a 4-mer by the that of its 3-prefix
		}
		
		
		// Normalize the 3-mers by dividing their prefix 2-mers
		//float threebase_sum = 0; // the sum of frequencies of all 3-mers
		flag2=0;
		iter1=hash_threebase.begin();
		for (iter = hash_threebase.begin(); iter != hash_threebase.end(); iter ++)
		{
			if(flag2%4==0)
			{
				sum=0;
				for (int flag1=0; flag1 < 4; flag1++)
				{					
					sum+=iter1->second;
					iter1++;
				}
				iter->second /= sum;
			}
			else
			{
				iter->second /= sum;
			}
			flag2++;
			//iter->second /= hash_twobase[iter->first.substr(0, 2)];
			//threebase_sum += iter->second; // add the frequency of each 3-mer
		}
		
/* 		for (iter = threebase_freq.begin(); iter != threebase_freq.end(); iter ++)
		{
			iter->second /= threebase_sum;
		} // divide the occurrence of 3-mers by the sum of occurrences of all 3-mers */

		// Normalize the 2-mers by dividing their prefix 1-mers
		iter1=hash_twobase.begin();
		for (iter = hash_twobase.begin(); iter != hash_twobase.end(); iter ++)
		{
			if(flag2%4==0)
			{
				sum=0;
				for (int flag1=0; flag1 < 4; flag1++)
				{					
					sum+=iter1->second;
					iter1++;
				}
				iter->second /= sum;
			}
			else
			{
				iter->second /= sum;
			}
			flag2++;
			//iter->second /= hash_onebase[iter->first.substr(0, 1)];
		}

		// Normalize the 1-mers by dividing the total number of nucleotides
		for (iter = hash_onebase.begin(); iter != hash_onebase.end(); iter ++)
		{
			sum0 += iter->second;// sum of frequencies of all nucleotides
		}

		for (iter = hash_onebase.begin(); iter != hash_onebase.end(); iter ++)
		{
			iter->second /= sum0; // divide the frequencies of all nucleotides by
			// the sum of frequencies of all nucleotides
		}
	}
	else if (flag == 2)
	{
		for (iter = hash_threebase.begin(); iter != hash_threebase.end(); iter ++)
		{
			iter->second /= hash_twobase[iter->first.substr(0, 2)];
		}

		
		for (iter = hash_twobase.begin(); iter != hash_twobase.end(); iter ++)
		{
			iter->second /= hash_onebase[iter->first.substr(0, 1)];
		}

		
		for (iter = hash_onebase.begin(); iter != hash_onebase.end(); iter ++)
		{
			sum += iter->second;
		}

		for (iter = hash_onebase.begin(); iter != hash_onebase.end(); iter ++)
		{
			iter->second /= sum;
		}
	}
	else if (flag == 1)
	{
		for (iter = hash_twobase.begin(); iter != hash_twobase.end(); iter ++)
		{
			iter->second /= hash_onebase[iter->first.substr(0, 1)];
		}

		
		for (iter = hash_onebase.begin(); iter != hash_onebase.end(); iter ++)
		{
			sum += iter->second;
		}

		for (iter = hash_onebase.begin(); iter != hash_onebase.end(); iter ++)
		{
			iter->second /= sum;
		}
	}
	else if (flag == 0)
	{
		for (iter = hash_onebase.begin(); iter != hash_onebase.end(); iter ++)
		{
			sum += iter->second;
		}

		for (iter = hash_onebase.begin(); iter != hash_onebase.end(); iter ++)
		{
			iter->second /= sum;
		}
	}

	cout << "Finished claculating the k-mer frequencies.\n";

	// End
	
	
	
	

	// Generate the simulated sequences with the same number and lengths
	float* values0, *values1, *values2, *values3;
	values0 = new float [SIZE];
	values1 = new float [SIZE];
	values2 = new float [SIZE];
	values3 = new float [SIZE];
	string tempstr;

	for (int i = 0; i < f_in.strand.size(); i ++)
	{
		ostringstream segment_fd; // the stream for segmentation
		segment_fd << (i + 1); // read into the string on next line
		f_bg.name.push_back(segment_fd.str()); // push back the sequence names
		f_bg.strand.push_back(tempstr); // push back an empty string as place holder
	}
	
	//cout << "Line 463\n";

	if (flag == 0)
	{
		for (int i = 0; i < SIZE; i++)
		{
			tempstr.clear();
			tempstr.push_back(alphabet[i]); // each nucleotide
			values0[i] = hash_onebase[tempstr]; // frequency for each nucleotide
		}
		
		for (int i = 0; i < f_in.strand.size(); i ++)
		{
			for (int j = 0; j < f_in.strand[i].size(); j ++)
			{
				f_bg.strand[i].push_back(alphabet[genmulone(values0, SIZE)]);
			  // generate a random nucleotide
				// based on the nucleotide frequencies
			}
			
			//cout << f_bg.strand[i] << "\n";
		}
	}
	else if (flag == 1)
	{
		for (int i = 0; i < SIZE; i ++) // the same with flag = 0
		{
			tempstr.clear();
			tempstr.push_back(alphabet[i]);
			values0[i] = hash_onebase[tempstr];
		}
		
		for (int i = 0; i < f_in.strand.size(); i ++)
		{
			f_bg.strand[i].push_back(alphabet[genmulone(values0, SIZE)]); // the first nucleotide
		  //cout << f_bg.strand[i] << "\n";
		  //cout << f_in.strand[i].size() << "\n";

			for (int j = 1; j < f_in.strand[i].size(); j ++)
			{
			  //cout << "j: " << j <<"\n";
			  
				for (int k = 0; k < SIZE; k ++)
				{
					tempstr.clear();
					tempstr.push_back(f_bg.strand[i][j - 1]); // the previous nucleotide
					//cout << "Line 507: " << f_bg.strand[i][j - 1] << "\n";
					tempstr.push_back(alphabet[k]); // the current nucleotide
					values1[k] = hash_twobase[tempstr]; // the frequency of 2-mer
					//cout << values1[k] << "\n";
				}
				
				//cout << "Line 511\n";

				// f_bg.strand[i] += alphabet[genmulone(values1, SIZE)];
				//cout << alphabet[genmulone(values1, SIZE)] << "\n";
				f_bg.strand[i].push_back(alphabet[genmulone(values1, SIZE)]);
				// add a random nucleotide iteratively
				//cout << "line 516\n";
			}
			
			//cout << "Seq: " << i << "\n";
			//cout << f_in.strand[i] << "\n";
		}
	}
	else if (flag == 2)
	{
		for (int i = 0; i < SIZE; i ++)
		{
			tempstr.clear();
			tempstr.push_back(alphabet[i]);
			values0[i] = hash_onebase[tempstr];
		} // the same with flag == 0
		for (int i = 0; i < f_in.strand.size(); i ++)
		{
			f_bg.strand[i].push_back(alphabet[genmulone(values0, SIZE)]); // the first nucleotide

			for (int k = 0; k < SIZE; k ++)
			{
				tempstr.clear();
				tempstr.push_back(f_bg.strand[i][0]);
				tempstr.push_back(alphabet[k]);
				values1[k] = hash_twobase[tempstr];
			} // the same with flag == 1

			f_bg.strand[i].push_back(alphabet[genmulone(values1, SIZE)]); // the second nucleotide

			for (int j = 2; j < f_in.strand[i].size(); j ++)
			{
				tempstr.clear();
				tempstr.push_back(f_bg.strand[i][j - 2]);
				tempstr.push_back(f_bg.strand[i][j - 1]);
				for (int k = 0; k < SIZE; k ++)
				{
					tempstr.push_back(alphabet[k]);
					values2[k] = hash_threebase[tempstr]; // the third nucleotide
				}
				f_bg.strand[i].push_back(alphabet[genmulone(values2, SIZE)]);
			}
		}
	}
	else if (flag == 3)
	{
	  //cout << "Flag = 3\n";
	  	float sum_n=0;
		for (int i = 0; i < SIZE; i ++)
		{
			tempstr.clear();
			tempstr.push_back(alphabet[i]);
			values0[i] = hash_onebase[tempstr];
		}
		
		for (int i = 0; i < f_in.strand.size(); i ++)
		{
		  //cout << "flag " << flag << "\n";
		  
			f_bg.strand[i].push_back(alphabet[genmulone(values0, SIZE)]); // the first nucleotide
			for (int k = 0; k < SIZE; k ++)
			{
				tempstr.clear();
				tempstr.push_back(f_bg.strand[i][0]);
				tempstr.push_back(alphabet[k]);
				values1[k] = hash_twobase[tempstr];

			}
			
			f_bg.strand[i].push_back(alphabet[genmulone(values1, SIZE)]); // the second nucleotide
			float sum_test=0;
			for (int k = 0; k < SIZE; k ++)
			{
				tempstr.clear();
				tempstr.push_back(f_bg.strand[i][0]);
				tempstr.push_back(f_bg.strand[i][1]);
				tempstr.push_back(alphabet[k]);
				values2[k] = hash_threebase[tempstr];
				sum_test+=values2[k];
			}
			
			f_bg.strand[i].push_back(alphabet[genmulone(values2, SIZE)]); // the third nucleotide
			//cout << "Line 577\n";
			sum_test=0;
			for (int j = 3; j < f_in.strand[i].size(); j ++)
			{
			  //cout << "Position: " << j << "\n";
				for (int k = 0; k < SIZE; k ++)
				{
					tempstr.clear();
					tempstr.push_back(f_bg.strand[i][j - 3]);
					tempstr.push_back(f_bg.strand[i][j - 2]);
					tempstr.push_back(f_bg.strand[i][j - 1]);
					tempstr.push_back(alphabet[k]);
					values3[k] = hash_fourbase[tempstr];
					sum_test+=values3[k];
				}
				
				//cout << values3[0] + values3[1]+ values3[2]+ values3[3] << "\n";
				//cout << alphabet[genmulone(values3, SIZE)] << "\n";
				f_bg.strand[i].push_back(alphabet[genmulone(values3, SIZE)]); // the four nucleotide
				//cout << f_bg.strand[i] << "\n";
			}
			//cout << "Line 592\n";
		}
	}
	
	//cout << "Line 592\n";
	
	struct kmer_package kmer_pkg; // the 3-mer frequencies and transition matrix
	
	if (flag == 3)
	{
	  kmer_pkg.AA = hash_onebase; 
	  kmer_pkg.B = hash_twobase;
	  kmer_pkg.C = hash_threebase; // the 3-mer frequencies
	  kmer_pkg.D = hash_fourbase; // the hash table to count the 4-mer frequencies,
	  // which can serve as the transition matrix B
	}
    // else if (flag == 2)
    // {
    //   struct kmer_package kmer_pkg; // the 2-mer frequencies and transition matrix
    //   kmer_pkg.B = twobase_freq; // the 2-mer frequencies
    //   kmer_pkg.T = hash_threebase; // the hash table to count the 3-mer frequencies,
    //   // which can serve as the transition matrix B
    // }
    // else if (flag == 1)
    // {
    //   struct kmer_package kmer_pkg; // the 1-mer frequencies and transition matrix
    //   kmer_pkg.B = onebase_freq; // the 1-mer frequencies
    //   kmer_pkg.T = hash_twobase; // the hash table to count the 2-mer frequencies,
    //   // which can serve as the transition matrix B
    // }
    // else if (flag == 0)
    // {
    //   struct kmer_package kmer_pkg; // the 1-mer frequencies and transition matrix
    //   kmer_pkg.B = onebase_freq; // the 1-mer frequencies
    //   kmer_pkg.T = hash_twobase; // the hash table to count the 2-mer frequencies,
    //   // which can serve as the transition matrix B
    // }

	cout << "Finished generating background sequences.\n";
	delete [] values0;
	delete [] values1;
	delete [] values2;
	delete [] values3;
	
	return(kmer_pkg);
}
