#!/bin/bash

# Use default parameters, i.e. use 3 order Markov model to generate background sequences, and 
# save the results in *.meme, *.site and *.spic files with the input file name as prefix.
./ProSampler -i Data_1.fa

# Set the order of Markov model to generate background sequences using "-b" parameter
# ./ProSampler -i Data_1.fa -b 3

# Set the name of background file manually
# ./ProSampler -i Data_1.fa -b Data_1.bg

# Set the prefix for output files in *.meme, *.site and *.spic format.
# In this case, you will get output files named Output.meme, Output.site and Output.spic.
# ./ProSampler -i Data_1.fa -o Output
