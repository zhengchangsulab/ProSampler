
// This version use z-test all along.

#include <iostream>
#include <fstream>
#include <string>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <ctype.h>
#include <vector>
#include <map>
#include <math.h>
#include <algorithm>
#include <deque>
#include <time.h>
#include <iomanip>
#include <limits.h>

using namespace std;

#define TRIVIAL_LEN 6
#define DEL_LEN 6
#define OVERLAP 8
#define PRECISE 4
#define MULTIPLE 100
#define MIN(a, b) ((a)<(b)?(a):(b))

typedef struct str_int_int
{
	string header;
	char strand;
	int begin;
	int end;
} st;

typedef struct name_seq
{
	vector<string> name;
	vector<string> strand;
} sequence;

typedef vector<int> int_vector;
typedef vector<double> double_vector;
typedef vector<char> char_vector;

typedef struct kmer_occurr
{
	vector<string> kmer;
	int_vector occurr;
	double_vector cover1;
	double_vector cover2;
	double_vector score;
	vector<int_vector> site;
} kmer_set;

typedef struct kmer_lmer
{
	string kmer;
	int occurr;
	double cover1;
	double cover2;
	double score;
	vector<int> site;
	vector<double_vector> left;
	vector<double_vector> right;
} kmer_all;

typedef struct psm_occurr
{
	vector<int> set;
	vector<double_vector> mat;
	int occurr;
	string cons;
	double score;
	double cover1;
	double cover2;
} psm;

typedef struct left_psm_right
{
	vector<int> set;
	vector<double_vector> mat;
	int occurr;
	vector<double_vector> left;
	vector<double_vector> right;
	vector<int> site;
	int begin;
	int end;
	double cover1;
	double cover2;
	double score;
} pre_mtf;

typedef struct set_mat_alength_nsites_cons
{
	vector<int> set;
	vector<double_vector> mat;
	int alength;
	int nsites;
	string cons;
	string rev_cons;
	string deg;
	string rev_deg;
	double score;
	vector<st> site;
	double cover1;
	double cover2;
} mtf;

typedef struct mat_vec_mat
{
	vector<double_vector> pfm;
	vector<double> ic;
	vector<double_vector> pssm;
} spic;

int f_in_id, f_bg_id, f_out_id, top_num;

int kmer_length=8;
int lmer_length=6;
int num_deg=1;
int hd_thr=1;
int redundant_thr=2;
int num_mtf=-1;
int str_flag=1;
int help_flag=0;
int num_iter=100;
double sw_thr=1.8;

double sum_exp=0;
double sum_bg=0;

double thr1=8;
double thr2=1.96;
double thr3=4.5;

char alphabet[4]={'A', 'C', 'G', 'T'};
map<char, int> r_alphabet;
double nt_freq[4];
char wild_card[14], reverse_wild[14], begin_pkg[64], end_pkg[64];
time_t begin_t, end_t;

/*************************************************************************************************
 *
 * FUnction free_pt used to free the saving space of pointer
 *
 ************************************************************************************************/

template <typename T>

void free_pt(T* tmp_pt)
{
	if(tmp_pt!=NULL)
	{
		delete [] tmp_pt;
		tmp_pt=NULL;
	}
}

/*************************************************************************************************
 *
 * Function called by quickSort
 *
 ************************************************************************************************/

template <class T>
int partition(T a[], int start, int stop, int id[])
{
    	int temp_id, up=start, down=stop-1;
    	T temp_value, part=a[stop];
    	if(stop<=start) return start;

    	while(true)
    	{
        	while(a[up]<part) up++;
        	while(part<a[down] && (up<down)) down--;

        	if(up>=down) break;

        	temp_value=a[up];  a[up]=a[down]; a[down]=temp_value;
        	temp_id=id[up]; id[up]=id[down]; id[down]=temp_id;

        	up++; down--;
    	}

    	temp_value=a[up]; a[up]=a[stop]; a[stop]=temp_value;
    	temp_id=id[up]; id[up]=id[stop]; id[stop]=temp_id;
    	return up;
}

/*************************************************************************************************
 *
 * Function quickSort used to sort integers
 *
 ************************************************************************************************/

template <class T>
void quickSort(T a[], int start, int stop, int id[])
{
    	int i;
    	if(stop<=start) return;

    	i=partition(a,start,stop,id);
    	quickSort(a,start,i-1,id);
    	quickSort(a,i+1,stop,id);
}

/* Period parameters */
#define N 624
#define M 397
#define MATRIX_A 0x9908b0dfUL   /* constant vector a */
#define UPPER_MASK 0x80000000UL /* most significant w-r bits */
#define LOWER_MASK 0x7fffffffUL /* least significant r bits */

static unsigned long mt[N]; /* the array for the state vector  */
static int mti=N+1; /* mti==N+1 means mt[N] is not initialized */

/* initializes mt[N] with a seed */
void init_genrand(unsigned long s)
{
    	mt[0]= s & 0xffffffffUL;
    	for (mti=1; mti<N; mti++)
	{
        	mt[mti] =
            	(1812433253UL * (mt[mti-1] ^ (mt[mti-1] >> 30)) + mti);
        	/* See Knuth TAOCP Vol2. 3rd Ed. P.106 for multiplier. */
        	/* In the previous versions, MSBs of the seed affect   */
        	/* only MSBs of the array mt[].                        */
        	/* 2002/01/09 modified by Makoto Matsumoto             */
        	mt[mti] &= 0xffffffffUL;
        	/* for >32 bit machines */
    	}
}

/* initialize by an array with array-length */
/* init_key is the array for initializing keys */
/* key_length is its length */
/* slight change for C++, 2004/2/26 */
void init_by_array(unsigned long init_key[], int key_length)
{
    	int i, j, k;
    	init_genrand(19650218UL);
    	i=1; j=0;
    	k = (N>key_length ? N : key_length);
    	for (; k; k--)
	{
        	mt[i] = (mt[i] ^ ((mt[i-1] ^ (mt[i-1] >> 30)) * 1664525UL))
          	+ init_key[j] + j; /* non linear */
        	mt[i] &= 0xffffffffUL; /* for WORDSIZE > 32 machines */
        	i++; j++;
        	if (i>=N) { mt[0] = mt[N-1]; i=1; }
        	if (j>=key_length) j=0;
    	}
    	for (k=N-1; k; k--)
	{
        	mt[i] = (mt[i] ^ ((mt[i-1] ^ (mt[i-1] >> 30)) * 1566083941UL))
          	- i; /* non linear */
        	mt[i] &= 0xffffffffUL; /* for WORDSIZE > 32 machines */
        	i++;
        	if (i>=N) { mt[0] = mt[N-1]; i=1; }
    	}

    	mt[0] = 0x80000000UL; /* MSB is 1; assuring non-zero initial array */
}

/* generates a random number on [0,0xffffffff]-interval */
uint32_t genrand_int32(void)
{
  	unsigned long y;
  	static unsigned long mag01[2]={0x0UL, MATRIX_A};
  	/* mag01[x] = x * MATRIX_A  for x=0,1 */

  	if (mti >= N)
	{ /* generate N words at one time */
    		int kk;

    		if (mti == N+1)   /* if init_genrand() has not been called, */
      		init_genrand(5489UL); /* a default initial seed is used */

    		for (kk=0;kk<N-M;kk++)
		{
      			y = (mt[kk]&UPPER_MASK)|(mt[kk+1]&LOWER_MASK);
      			mt[kk] = mt[kk+M] ^ (y >> 1) ^ mag01[y & 0x1UL];
    		}
    		for (;kk<N-1;kk++)
    		{
      			y = (mt[kk]&UPPER_MASK)|(mt[kk+1]&LOWER_MASK);
      			mt[kk] = mt[kk+(M-N)] ^ (y >> 1) ^ mag01[y & 0x1UL];
    		}
    		y = (mt[N-1]&UPPER_MASK)|(mt[0]&LOWER_MASK);
    		mt[N-1] = mt[M-1] ^ (y >> 1) ^ mag01[y & 0x1UL];

    		mti = 0;
  	}

  	y = mt[mti++];

  	/* Tempering */
  	y ^= (y >> 11);
  	y ^= (y << 7) & 0x9d2c5680UL;
  	y ^= (y << 15) & 0xefc60000UL;
  	y ^= (y >> 18);

  	return y;
}

uint64_t genrand_int64(void)
{
  	uint64_t x, y;

  	x = genrand_int32(); y = genrand_int32();
  	return (x<<32)|y;
}

void init_mersenne(void)
{
  	unsigned long init[4]={0x123, 0x234, 0x345, 0x456}, length=4;
  	init_by_array(init, length);
}

double genrand_real2(void)
{
 	return genrand_int64()*(1.0/(4294967296.0*4294967296.0));
}

double ranf(void)
{
  	init_genrand((unsigned)time(NULL)+rand());
  	return (genrand_real2());
}

double genunf(double low,double high)
{
	static double genunf;
    	genunf = low+(high-low)*ranf();

    	return genunf;
}

//generate a random variable (scalar) follows multinomial distribution, used to sample motif starting location (alignment variable)
int genmulone(double *p_input,long ncat)
{
	int i;
	double *p = NULL;
	p = new double [ncat];
	for(i=0;i<ncat;i++) p[i]=p_input[i];

	int*q = NULL;
	q = new int [ncat];
	for(i=0;i<ncat;i++) q[i]=i;

	quickSort(p, 0, ncat-1, q);

	double prob=genunf(0,1);
	int outcome=ncat-1;
	while (outcome>=0  && prob > p[outcome])
	{
 		prob -= p[outcome];
 		outcome--;
	}

	int res=q[outcome];
	free_pt(p);
	free_pt(q);

	return res;
}

/*************************************************************************************************
 *
 * Function reverse_sort used to reverse the sort order
 *
 ************************************************************************************************/

void reverse_sort(int id[], int length)
{
	int *temp_id;
	temp_id=new int [length];
	int i;

	for(i=0; i<length; i++)
	{
		temp_id[i]=id[length-1-i];
	}
	for(i=0; i<length; i++)
	{
		id[i]=temp_id[i];
	}

	free_pt(temp_id);
}

/*************************************************************************************************
 *
 * Function usage used to print the usage of this program
 *
 ************************************************************************************************/

void usage()
{
	cout<<endl<<"================================================================================================================================================================="<<endl;
	cout<<"Usage: ./ProSampler [options]"<<endl;
	cout<<endl<<"Parameters:"<<endl;
	cout<<"-i: The name of input file"<<endl;
	cout<<"-b: The name of background file"<<endl;
	cout<<"-d: The number of degenerate positions in one PSM"<<endl;
	cout<<"-o: The name of output file"<<endl;
	cout<<"-m: The number of output motifs (default: all)"<<endl;
	cout<<"-f: The iteration time for each motif (default: 100)"<<endl;
	cout<<"-k: The length of k-mers (default: 8)"<<endl;
	cout<<"-l: The length of l-mer segments (default: 6)"<<endl;
	cout<<"-c: The threshold for Hamming Distance used to connect nodes (default: 1)"<<endl;
	cout<<"-r: The threshold for deleting redundant motifs based on consensus (default: 1)"<<endl;
	cout<<"-p: The boolean variable representing whether we consider positive strands only or both strands (default: 2)"<<endl;
	cout<<"-t: The threshold to choose significant k-mers (default: 8.00)"<<endl;
	cout<<"-w: The threshold to choose sub-significant k-mers (default: 4.50)"<<endl;
	cout<<"-z: The threshold to refine the preliminary motifs (default: 1.96)"<<endl;
	cout<<"-h: Print this message (default: 0)"<<endl;
	cout<<"-s: SW score threshold used to construct graph (default: 1.80)"<<endl;
	cout<<"================================================================================================================================================================="<<endl;
}

/*************************************************************************************************
 *
 * Function parse_opt used to parse the input parameters to this program
 *
 ************************************************************************************************/

 void parse_opt(int argc, char** argv)
 {
	 int i;

	 if(argc<7)
	 {
		 cout<<"Error: The number of input parameters is wrong. Please check the input parameters again."<<endl;
		 usage();
		 exit(0);
	 }

	 for(i=1; i<argc-1; i++)
	 {
		 if(strcmp(argv[i], "-i")==0) {f_in_id=i+1; i++;}
		 else if(strcmp(argv[i], "-b")==0) {f_bg_id=i+1; i++;}
		 else if(strcmp(argv[i], "-o")==0) {f_out_id=i+1; i++;}
		 else if(strcmp(argv[i], "-d")==0) {num_deg=atoi(argv[i+1]); i++;}
		 else if(strcmp(argv[i], "-k")==0) {kmer_length=atoi(argv[i+1]); i++;}
		 else if(strcmp(argv[i], "-l")==0) {lmer_length=atoi(argv[i+1]); i++;}
		 else if(strcmp(argv[i], "-m")==0) {num_mtf=atoi(argv[i+1]); i++;}
		 else if(strcmp(argv[i], "-c")==0) {hd_thr=atoi(argv[i+1]); i++;}
		 else if(strcmp(argv[i], "-r")==0) {redundant_thr=atoi(argv[i+1]); i++;}
		 else if(strcmp(argv[i], "-p")==0) {str_flag=atoi(argv[i+1]); i++;}
		 else if(strcmp(argv[i], "-f")==0) {num_iter=atoi(argv[i+1]); i++;}
		 else if(strcmp(argv[i], "-t")==0) {thr1=atof(argv[i+1]); i++;}
		 else if(strcmp(argv[i], "-w")==0) {thr3=atof(argv[i+1]); i++;}
		 else if(strcmp(argv[i], "-z")==0) {thr2=atof(argv[i+1]); i++;}
		 else if(strcmp(argv[i], "-h")==0) {help_flag=atoi(argv[i+1]); i++;}
		 else if(strcmp(argv[i], "-s")==0) {sw_thr=atof(argv[i+1]); i++;}
	 }

	 cout<<"Finished parsing input parameters to the program."<<endl;
 }

/*************************************************************************************************
 *
 * Function de_lower used to substitue lowercase letters with uppercase letters
 *
 ************************************************************************************************/

void de_lower(sequence& seq)
{
	int i, j;

	for(i=0; i<seq.strand.size(); i++)
	{
		for(j=0; j<seq.strand[i].length(); j++)
		{
			if(islower(seq.strand[i][j]))
			{
				seq.strand[i][j]=toupper(seq.strand[i][j]);
			}
		}
	}
}

/*************************************************************************************************
 *
 * Function de_degenerate used to substitue 'N' with 'A', 'C', 'G'or 'T' randomly
 *
 ************************************************************************************************/

void de_degenerate(sequence& seq)
{
	int i, j;

	for(i=0; i<seq.strand.size(); i++)
	{
		for(j=0; j<seq.strand[i].length(); j++)
		{
			if(seq.strand[i][j]!='A' && seq.strand[i][j]!='C' && seq.strand[i][j]!='G' && seq.strand[i][j]!='T')
			{
				seq.strand[i][j]='N';
			}
		}
	}
}

/*************************************************************************************************
 *
 * Function seq_reverse used to compute the reverse strand of the input sequences
 *
 ************************************************************************************************/

void seq_reverse(sequence& seq, vector<string>& strand)
{
	int i, j;
	string str;
	strand.clear();

	for(i=0;i<seq.strand.size(); i++)
	{
		str.assign(seq.strand[i].rbegin(), seq.strand[i].rend());
		for(j=0; j<str.length(); j++)
		{
			switch(str[j])
			{
				case 'A':
				str[j]='T';
				break;
				case 'C':
				str[j]='G';
				break;
				case 'G':
				str[j]='C';
				break;
				case 'T':
				str[j]='A';
				break;
				default:
				break;
			}
		}
		strand.push_back(str);
	}
}

/*************************************************************************************************
 *
 * Function seq_generate to generate the final version of sequences
 *
 ************************************************************************************************/

void seq_generate(sequence& seq_pos, sequence& seq_final, int str_flag)
{
	if(str_flag==1)
	{
			seq_final=seq_pos;
	}
	else if(str_flag==2)
	{
		vector<string> strand;
		seq_reverse(seq_pos, strand);
		if(seq_pos.strand.size()!=strand.size())
		{
			cerr<<"Error: The number of positive strands of the sequences is not equal to the number of negative strands."<<endl;
			exit(1);
		}
		seq_final.name=seq_pos.name;
		seq_final.strand.clear();
		for(int i=0; i<seq_final.name.size(); i++)
		{
			seq_final.strand.push_back(seq_pos.strand[i]);
			seq_final.strand.push_back(strand[i]);
		}
		if(seq_final.name.size()*2!=seq_final.strand.size())
		{
			cerr<<"Error: The number of sequence names mismatches that of sequence strands."<<endl;
			exit(1);
		}
	}
	else
	{
		cerr<<"Error: The parameter str_flag should be chosen from 1 or 2."<<endl<<"Please check the parameters again."<<endl;
		exit(1);
	}
}

/*************************************************************************************************
 *
 * Function load_data used to read data into this program
 *
 ************************************************************************************************/

void load_data(char* file_name, sequence& seq)
{
	seq.name.clear();
	seq.strand.clear();

	ifstream file_op(file_name);
	if(!file_op)
	{
		cerr<<"Error: Can't open file "<<file_name<<"!"<<endl;
		exit(1);
	}

	string line;
	while(!file_op.eof())
	{
		getline(file_op, line);
			
		if(line[0]=='>')
		{
			seq.name.push_back(line.substr(1));
		}
		else if(!line.empty())
		{
			seq.strand.push_back(line);
		}
	}

	if(seq.name.size()!=seq.strand.size())
	{
		cerr<<"Error: The number of sequence name lines is not equal to the number of sequence lines!"<<endl;
		exit(1);
	}

	cout<<"Finished loading FASTA file "<<file_name<<" into sequence variable."<<endl;
}

/*************************************************************************************************
 *
 * Function free_seq used to free the space of sequences
 *
 ************************************************************************************************/

void free_seq(sequence& seq)
{
	int i;
	for(i=0; i<seq.name.size(); i++)
	{
		string().swap(seq.name[i]);
	}
	vector<string>().swap(seq.name);

	for(i=0; i<seq.strand.size(); i++)
	{
		string().swap(seq.strand[i]);
	}
	vector<string>().swap(seq.strand);
}

/*************************************************************************************************
 *
 * Function nt_stat used to calculate the frequencies of nucleotides
 *
 ************************************************************************************************/

void nt_stat(sequence& seq_nondeg, double* nt_freq)
{
	int i, j;
	double sum=0;
	for(i=0; i<4; i++)
	{
		nt_freq[i]=0;
	}

	for(i=0; i<seq_nondeg.strand.size(); i++)
	{
		for(j=0; j<seq_nondeg.strand[i].length(); j++)
		{
			switch(seq_nondeg.strand[i][j])
			{
				case 'A':
				nt_freq[0]++;
				break;
				case 'C':
				nt_freq[1]++;
				break;
				case 'G':
				nt_freq[2]++;
				break;
				case 'T':
				nt_freq[3]++;
				break;
				default:
				break;
			}
		}
	}

	for(i=0; i<4; i++)
	{
		sum+=nt_freq[i];
	}
	for(i=0; i<4; i++)
	{
		nt_freq[i]/=sum;
	}

	cout<<"Finished counting the nucleotide frequencies of the input FASTA file."<<endl;
}

/*************************************************************************************************
 *
 * Function kmer_count used to count the occurrence numbers of k-mers
 *
 ************************************************************************************************/

void kmer_count(map<string, int_vector>& kmer_site, sequence& seq_final, int& lmer_length)
{
	int i, j;
	kmer_site.clear();

	if(str_flag==1)
	{
		for(i=0; i<seq_final.strand.size(); i++)
		{
			if(seq_final.strand[i].length()<kmer_length+2*lmer_length)
			{
				continue;
			}

			for(j=lmer_length; j<=seq_final.strand[i].length()-kmer_length-lmer_length; j++)
			{
				if(seq_final.strand[i].substr(j, kmer_length).find('N')!=seq_final
						.strand[i].substr(j, kmer_length).npos)
				{
					continue;
				}

				kmer_site[seq_final.strand[i].substr(j, kmer_length)]
					.push_back(i);
				kmer_site[seq_final.strand[i].substr(j, kmer_length)]
					.push_back(j);
			}
		}
	}
	else
	{
		for(i=0; i<seq_final.strand.size(); i+=2)
		{
			if(seq_final.strand[i].length()<kmer_length+2*lmer_length)
			{
				continue;
			}

			for(j=lmer_length; j<=seq_final.strand[i].length()-kmer_length-lmer_length; j++)
			{
				if(seq_final.strand[i].substr(j, kmer_length)
						.find('N')!=seq_final.strand[i]
						.substr(j, kmer_length).npos)
				{
					continue;
				}

				kmer_site[seq_final.strand[i]
					.substr(j, kmer_length)].push_back(i);
				kmer_site[seq_final.strand[i]
					.substr(j, kmer_length)].push_back(j);
			}
		}
	}

	cout<<"Finished counting "<<kmer_length<<"-mer occurrence numbers and sites."<<endl;
}

/*************************************************************************************************
 *
 * Function if_same used to get rid of the k-mers with low complexity (length: 5)
 *
 ************************************************************************************************/

int if_same(string str)
{
	int i, flag;
	flag=0;

	for(i=1; i<str.length(); i++)
	{
		if(str[0]!=str[i])
		{
			flag=1;
			break;
		}
	}

	return flag;
}

/*************************************************************************************************
 *
 * Function check_complex used to check complexity of a string
 *
 ************************************************************************************************/

int check_complex(string str)
{
	int flag=0;

	map<char, int> map_str;

	for(int i=0; i<str.length(); i++)
	{
		map_str[str[i]]++;
	}

	if(map_str.size()>=2)
	{
		flag=1;
	}

	return flag;
}

/*************************************************************************************************
 *
 * Function de_trivial used to get rid of the k-mers with low complexity (unfixed length)
 *
 ************************************************************************************************/

int de_trivial(string str)
{
	int flag=1;

	for(int i=0; i<=str.length()-TRIVIAL_LEN; i++)
	{
		if(!if_same(str.substr(i, TRIVIAL_LEN)))
		{
			flag=0;
			break;
		}
	}

	if(flag==1)
	{
		flag=check_complex(str);

	}

	return flag;
}

/*************************************************************************************************
 *
 * Function last_trivial used to get rid of the k-mers with low complexity (unfixed length)
 *
 ************************************************************************************************/

int last_trivial(string str)
{
	int flag=1;

	for(int i=0; i<=str.length()-DEL_LEN; i++)
	{
		if(!if_same(str.substr(i, DEL_LEN)))
		{
			flag=0;
			break;
		}
	}

	if(flag==1)
	{
		flag=check_complex(str);

	}

	return flag;
}

/*************************************************************************************************
 *
 * Function ztest used to perform two proportion z-test
 *
 ************************************************************************************************/

double ztest(double& cover1, double& cover2, double& sum1, double& sum2)
{
	double p1=cover1/sum1;
	double p2=cover2/sum2;
	double p=(cover1+cover2)/(sum1+sum2);
	double up=p1-p2;
	double down=sqrt(p*(1-p)*(1/sum1+1/sum2));
	double res=up/down;
	return res;
}

/*************************************************************************************************
 *
 * Function init_array used to initiate the array
 *
 ************************************************************************************************/

void init_array(int* flag_ar, int len, int start)
{
	for(int i=0; i<len; i++)
	{
		flag_ar[i]=start;
	}
}

/*************************************************************************************************
 *
 * Function site2cover used to transform site information into coverage information
 *
 ************************************************************************************************/

double site2cover(vector<int>& site, int seq_num)
{
	int* seq_ar;
	seq_ar=new int [seq_num];
	init_array(seq_ar, seq_num, 0);
	double sum=0;

	if(str_flag==2)
	{
		for(int i=0; i<site.size(); i+=2)
		{
			seq_ar[site[i]/2]=1;
		}
	}
	else
	{
		for(int i=0; i<site.size(); i+=2)
		{
			seq_ar[site[i]]=1;
		}
	}

	for(int i=0; i<seq_num; i++)
	{
		sum+=seq_ar[i];
	}

	free_pt(seq_ar);

	return sum;
}

/*************************************************************************************************
 *
 * Function choose_kmer used to calculate significant k-mers
 *
 ************************************************************************************************/

void choose_kmer(map<string, int_vector>& map_exp, map<string, int_vector>& map_bg, kmer_set& major_set, int seq_num, map<string, int>& fa_flag, kmer_set& minor_set)
{
	major_set.kmer.clear();
	major_set.cover1.clear();
	major_set.cover2.clear();
	major_set.site.clear();
	major_set.score.clear();

	double tmp_cover1, tmp_cover2;
	double z_sc;
	sum_exp=0;
	sum_bg=0;

	for(map<string, int_vector>::iterator i=map_exp.begin(); i!=map_exp.end(); i++)
	{
		if(fa_flag[i->first]==0)
		{
			continue;
		}

		sum_exp+=(i->second).size()/2;
	}

	sum_bg=sum_exp;

	for(map<string, int_vector>::iterator i=map_exp.begin(); i!=map_exp.end(); i++)
	{
		if(fa_flag[i->first]==0)
		{
			continue;
		}

		tmp_cover1=(i->second).size()/2;
		tmp_cover2=map_bg[i->first].size()/2;
		z_sc=ztest(tmp_cover1, tmp_cover2, sum_exp, sum_bg);

		if(z_sc>thr1)
		{
			major_set.kmer.push_back(i->first);
			major_set.occurr.push_back(tmp_cover1);
			major_set.cover1.push_back(tmp_cover1);
			major_set.cover2.push_back(tmp_cover2);
			major_set.site.push_back(i->second);
			major_set.score.push_back(z_sc);
		}
		else if(z_sc>thr3)
		{
			minor_set.kmer.push_back(i->first);
			minor_set.occurr.push_back(tmp_cover1);
			minor_set.cover1.push_back(tmp_cover1);
			minor_set.cover2.push_back(tmp_cover2);
			minor_set.site.push_back(i->second);
			minor_set.score.push_back(z_sc);
		}
	}

	cout<<"there are altogether "<<major_set.kmer.size()<<" significant "<<kmer_length<<"-mers left."<<endl;
	cout<<"there are altogether "<<minor_set.kmer.size()<<" sub-significant "<<kmer_length<<"-mers left."<<endl;
}

/*************************************************************************************************
 *
 * Function get_rev used to get the reverse strand of a string
 *
 ************************************************************************************************/

string get_rev(string str)
{
	string rev_str;	// The reverse string
	for(int i=str.length()-1; i>=0; i--)
	{
		rev_str+=alphabet[3-r_alphabet[str[i]]];
	}

	return rev_str;
}

/*************************************************************************************************
 *
 * Function check_parlindrome used to check whether the string is palindrome
 *
 ************************************************************************************************/

int check_parlindrome(string str)
{
	string rev_str=get_rev(str);	// The reverse string

	int flag=0;
	if(str==rev_str)
	{
		flag=1;
	}

	return flag;
}

/*************************************************************************************************
 *
 * Function reverse_st used to reverse the occurring sites of reverse supplementary strands
 *
 ************************************************************************************************/

void reverse_st(vector<int>& positive, vector<int>& negative, vector<string>& strand)
{
	negative=positive;

	for(int i=0; i<negative.size()-1; i+=2)
	{
		negative[i]++;
	}

	for(int i=1; i<negative.size(); i+=2)
	{
		negative[i]=strand[negative[i-1]].length()-negative[i]-kmer_length;
	}
}

/*************************************************************************************************
 *
 * Function comb_kmer used to combine reverse complementary k-mers
 *
 ************************************************************************************************/

void comb_kmer(map<string, int_vector>& kmer_site, map<string, int>& fa_flag, vector<string>& positive, map<string, int_vector>& kmer_bg, map<string, int>& bg_flag, vector<string>& negative)
{
	for(map<string, int_vector>::iterator it=kmer_site.begin(); it!=kmer_site.end(); it++)
	{
		fa_flag[it->first]=1;
	}

	for(map<string, int_vector>::iterator it=kmer_site.begin(); it!=kmer_site.end(); it++)
	{
		if(fa_flag[it->first]==0 || check_parlindrome(it->first))
		{
			continue;
		}

		string rev_str=get_rev(it->first);

		if(kmer_site.count(rev_str)>0)
		{
			fa_flag[rev_str]=0;
			vector<int> rev_site;
			rev_site.reserve(kmer_site[rev_str].size());
			reverse_st(kmer_site[rev_str], rev_site, positive);
			(it->second).insert((it->second).end(), rev_site.begin(), rev_site.end());
			kmer_site[rev_str].clear();
		}
	}

	bg_flag=fa_flag;

	for(map<string, int>::iterator it=bg_flag.begin(); it!=bg_flag.end(); it++)
	{
		if(it->second == 0)
		{
			continue;
		}

		string rev_str=get_rev(it->first);

		if(kmer_bg.count(rev_str)>0)
		{
			vector<int> rev_site;
			rev_site.reserve(kmer_bg[rev_str].size());
			reverse_st(kmer_bg[rev_str], rev_site, negative);
			kmer_bg[it->first].insert(kmer_bg[it->first].end(), rev_site.begin(), rev_site.end());
			kmer_bg[rev_str].clear();
		}
	}
}

/*************************************************************************************************
 *
 * Function kmer_sort used to sort the chosen k-mers
 *
 ************************************************************************************************/

void kmer_sort(kmer_set& chosen_kmers)
{
	double *kmer_score;
	int *kmer_id1;
	int num=chosen_kmers.score.size();
	kmer_score=new double [num];
	kmer_id1=new int [num];
	int i;

	for(i=0; i<num; i++)
	{
		kmer_score[i]=chosen_kmers.score[i];
		kmer_id1[i]=i;
	}

	quickSort(kmer_score, 0, num-1, kmer_id1);
	reverse_sort(kmer_id1, num);

	kmer_set temp_kmers;
	for(i=0; i<num; i++)
	{
		temp_kmers.kmer.push_back(chosen_kmers.kmer[kmer_id1[i]]);
		temp_kmers.score.push_back(chosen_kmers.score[kmer_id1[i]]);
		temp_kmers.cover1.push_back(chosen_kmers.cover1[kmer_id1[i]]);
		temp_kmers.cover2.push_back(chosen_kmers.cover2[kmer_id1[i]]);
		temp_kmers.occurr.push_back(chosen_kmers.occurr[kmer_id1[i]]);
		temp_kmers.site.push_back(chosen_kmers.site[kmer_id1[i]]);
	}

	chosen_kmers=temp_kmers;

	delete [] kmer_id1;
	delete [] kmer_score;

	cout<<"Finished sorting the significant "<<kmer_length<<"-mers based on z-scores."<<endl;
}

/*************************************************************************************************
 *
 * Function psm_sort used to sort all the PSMs and simultaneously delete the trivial PSMs
 *
 ************************************************************************************************/

void psm_sort(vector<psm>& psm_set)
{
	int *psm_id1;
	double *psm_scores;
	int num=psm_set.size();
	psm_scores=new double [num];
	psm_id1=new int [num];

	int i;

	for(i=0; i<num; i++)
	{
		psm_scores[i]=psm_set[i].score;
		psm_id1[i]=i;
	}

	quickSort(psm_scores, 0, num-1, psm_id1);
	reverse_sort(psm_id1, num);

	{
		vector<psm> tmp_psm;
		for(i=0; i<num; i++)
		{
			tmp_psm.push_back(psm_set[psm_id1[i]]);
		}

		psm_set.swap(tmp_psm);
	}

	delete [] psm_id1;
	delete [] psm_scores;

	cout<<"Finished sorting the PSMs in PSM set."<<endl;
	cout<<"Finished kicking out the trivial PSMs."<<endl<<"There're "<<psm_set.size()<<" PSMs left."<<endl;
}

/*************************************************************************************************
 *
 * Function generate_flag used to generate flags
 *
 ************************************************************************************************/

void generate_flag(int length, vector<int>& flag)
{
	int i;

	flag.reserve(length);

	for(i=0; i<length; i++)
	{
		flag.push_back(0);
	}
}

/*************************************************************************************************
 *
 * Function mask_kmer used to mask the selected k-mers
 *
 ************************************************************************************************/

void mask_kmer(vector<int>& set, vector<int>& kmer_flag)
{
	int i;

	for(i=0; i<set.size(); i++)
	{
		kmer_flag[set[i]]=1;
	}
}

/*************************************************************************************************
 *
 * Function find_seed used to find the id of next seed for partitioning k-mers
 *
 ************************************************************************************************/

int find_seed(vector<int>& kmer_flag)
{
	int out_id=-1;
	int i;

	for(i=0; i<kmer_flag.size(); i++)
	{
		if(kmer_flag[i]==0)
		{
			out_id=i;
			break;
		}
	}

	return out_id;
}

/*************************************************************************************************
 *
 * Function comp_hd used to get the Hamming Distance between two strings
 *
 ************************************************************************************************/

int comp_hd(string str1, string str2)
{
	if(str1.length()!=str2.length())
	{
		cerr<<"Error: only two strings with the same length can be compared to get Hamming Distance."<<endl;
		exit(0);
	}

	int hd=0;

	for(int i=0; i<str1.length(); i++)
	{
		if(str1[i]!=str2[i])
		{
			hd++;
		}
	}

	return hd;
}

/*************************************************************************************************
 *
 * Function kmer2psm used to transform all significant k-mers into PSMs
 *
 ************************************************************************************************/

void kmer2psm(vector<kmer_all>& kmer_final, vector<psm>& psm_set, int& top_num)
{
	psm_set.clear();
	psm tmp_psm;

	for(int i=0; i<top_num; i++)
	{
		tmp_psm.set.clear();
		tmp_psm.set.push_back(i);
		psm_set.push_back(tmp_psm);
	}

	for(int i=1; i<top_num; i++)
	{
		for(int j=0; j<i; j++)
		{
			if(comp_hd(kmer_final[i].kmer, kmer_final[j].kmer)<=hd_thr)
			{
				psm_set[i].set.push_back(j);
				psm_set[j].set.push_back(i);
			}
		}

		for(int j=top_num; j<kmer_final.size(); j++)
		{
			if(comp_hd(kmer_final[i].kmer, kmer_final[j].kmer)<=hd_thr)
			{
				psm_set[i].set.push_back(j);
			}
		}
	}

	for(int i=0; i<psm_set.size(); i++)
	{
		psm_set[i].occurr=0;

		for(int j=0; j<psm_set[i].set.size(); j++)
		{
			psm_set[i].occurr+=kmer_final[psm_set[i].set[j]].occurr;
		}
	}

	cout<<"Finished constructing PSMs."<<endl;
	cout<<"There are altogether "<<psm_set.size()<<" PSMs constructed."<<endl;
}

/*************************************************************************************************
 *
 * Function test_psm used to compute the z-scores of all PSMs
 *
 ************************************************************************************************/

void test_psm(vector<psm>& psm_set, double& sum1, double& sum2)
{
	for(int i=0; i<psm_set.size(); i++)
	{
		psm_set[i].score=ztest(psm_set[i].cover1, psm_set[i].cover2, sum1, sum2);
	}


	cout<<"Finished computing the z-scores for all PSMs"<<endl;
}

/*************************************************************************************************
 *
 * Function init_mat used to initiate the PSM matrix
 *
 ************************************************************************************************/

void init_mat(vector<double_vector>& psm_mat, int& length)
{
	for(int i=0; i<psm_mat.size(); i++)
	{
		psm_mat[i].clear();
	}
	psm_mat.clear();

	vector<double> tmp_vec;

	for(int i=0; i<4; i++)
	{
		tmp_vec.clear();
		for(int j=0; j<length; j++)
		{
			tmp_vec.push_back(0);
		}
		psm_mat.push_back(tmp_vec);
	}
}

/*************************************************************************************************
 *
 * Function comp_mat used to compute the PSM matrix based on k-mer set of PSM
 *
 ************************************************************************************************/

void comp_mat(vector<double_vector>& psm_mat, vector<int>& psm_set, vector<kmer_all>& kmer_final, int& length)
{
	int i, j;

	init_mat(psm_mat, length);

	for(i=0; i<psm_set.size(); i++)
	{
		for(j=0; j<length; j++)
		{
			psm_mat[r_alphabet[kmer_final[psm_set[i]].kmer[j]]][j]+=kmer_final[psm_set[i]].occurr;
		}
	}
}

/*************************************************************************************************
 *
 * Function norm_mat used to normalize the matrices of the PSMs
 *
 ************************************************************************************************/

void norm_mat(vector<double_vector>& tmp_mat, int& occurr, int& length)
{
	for(int i=0; i<4; i++)
	{
		for(int j=0; j<length; j++)
		{
			tmp_mat[i][j]/=occurr;
		}
	}
}

/*************************************************************************************************
 *
 * Function fill_psm used to compute the matrices for all PSMs
 *
 ************************************************************************************************/

void fill_psm(vector<psm>& psm_set, vector<kmer_all>& kmer_final, int& length)
{
	int i;

	for(i=0; i<psm_set.size(); i++)
	{
		comp_mat(psm_set[i].mat, psm_set[i].set, kmer_final, length);
		norm_mat(psm_set[i].mat, psm_set[i].occurr, length);
	}

	cout<<"Finished computing the matrices information of each PSM."<<endl;
}

/*************************************************************************************************
 *
 * Function init_str used to initiate the information of the consensus string
 *
 ************************************************************************************************/

void init_str(string& str, int length)
{
	str.assign(length, 'A');
}

/*************************************************************************************************
 *
 * Function max_col used to choose the element with the maximum value in this column
 *
 ************************************************************************************************/

int max_col(vector<double_vector>& mat, int col)
{
	double max_val=0;
	int max_id=0;

	for(int i=0; i<mat.size(); i++)
	{
		if(mat[i][col]>max_val)
		{
			max_val=mat[i][col];
			max_id=i;
		}
	}

	return max_id;
}

/*************************************************************************************************
 *
 * Function get_cons used to compute the consensus string for the current PSM
 *
 ************************************************************************************************/

void get_cons(string& cons, vector<double_vector>& mat)
{
	int i;

	init_str(cons, mat[0].size());

	for(i=0; i<cons.length(); i++)
	{
		cons[i]=alphabet[max_col(mat, i)];
	}
}

/*************************************************************************************************
 *
 * Function comp_cons used to compute the consensus strings of the PSMs
 *
 ************************************************************************************************/

void comp_cons(vector<psm>& psm_set)
{
	int i;

	for(i=0; i<psm_set.size(); i++)
	{
		get_cons(psm_set[i].cons, psm_set[i].mat);
	}

	cout<<"Finished computing the consensus strings for each PSM."<<endl;
}

/*************************************************************************************************
 *
 * Function add_str used to add one flanking segment to the matrix
 *
 ************************************************************************************************/

void add_str(vector<double_vector>& tmp_mat, string str)
{
	for(int i=0; i<str.size(); i++)
	{
		tmp_mat[r_alphabet[str[i]]][i]++;
	}
}

/*************************************************************************************************
 *
 * Function get_flank used to get the left and right flanking matrices
 *
 ************************************************************************************************/

void get_flank(vector<double_vector>& tmp_mat, vector<int>& site, sequence& seq_final, int direct, int id)
{
	init_mat(tmp_mat, lmer_length);

	for(int i=0; i<site.size(); i+=2)
	{
		if(direct==-1)
		{
			add_str(tmp_mat, seq_final.strand[site[i]].substr(site[i+1]-lmer_length, lmer_length));
		}
		else if(direct==1)
		{
			add_str(tmp_mat, seq_final.strand[site[i]].substr(site[i+1]+kmer_length, lmer_length));
		}
		else
		{
			cerr<<"Error: There's errors in function get_flank. Please check the parameters."<<endl;
			exit(0);
		}
	}
}

/*************************************************************************************************
 *
 * Function combine_major used to combine two sets
 *
 ************************************************************************************************/

int combine_major(kmer_set& major_set, kmer_set& minor_set)
{
	int res=major_set.kmer.size();
	major_set.kmer.insert(major_set.kmer.end(), minor_set.kmer.begin(), minor_set.kmer.end());
	major_set.occurr.insert(major_set.occurr.end(), minor_set.occurr.begin(), minor_set.occurr.end());
	major_set.cover1.insert(major_set.cover1.end(), minor_set.cover1.begin(), minor_set.cover1.end());
	major_set.cover2.insert(major_set.cover2.end(), minor_set.cover2.begin(), minor_set.cover2.end());
	major_set.score.insert(major_set.score.end(), minor_set.score.begin(), minor_set.score.end());
	major_set.site.insert(major_set.site.end(), minor_set.site.begin(), minor_set.site.end());

	return res;
}
	
/*************************************************************************************************
 *
 * Function fill_kmer used to obtain the k-mer information as well as their flanking segments
 *
 ************************************************************************************************/

void fill_kmer(kmer_set& major_set, vector<kmer_all>& kmer_final, int seq_num, sequence& seq_final)
{
	kmer_all tmp_kmer;

	for(int i=0; i<major_set.kmer.size(); i++)
	{
		tmp_kmer.kmer=major_set.kmer[i];
		tmp_kmer.occurr=major_set.occurr[i];
		tmp_kmer.cover1=major_set.cover1[i];
		tmp_kmer.cover2=major_set.cover2[i];
		tmp_kmer.site=major_set.site[i];
		tmp_kmer.score=major_set.score[i];
		get_flank(tmp_kmer.left, major_set.site[i], seq_final, -1, i);
		get_flank(tmp_kmer.right, major_set.site[i], seq_final, 1, i);
		kmer_final.push_back(tmp_kmer);
	}

	cout<<"Finished calculating the profile matrices by the flanking segments beside the "<<kmer_length<<"-mers."<<endl;
}

/*************************************************************************************************
 *
 * Function free_kmer used to free the memory of kmer_set
 *
 ************************************************************************************************/

void free_kmer(kmer_set& major_set)
{
	for(int i=0; i<major_set.kmer.size(); i++)
	{
		string().swap(major_set.kmer[i]);
		vector<int>().swap(major_set.site[i]);
	}
	vector<string>().swap(major_set.kmer);
	vector<int_vector>().swap(major_set.site);
}

/*************************************************************************************************
 *
 * Function comp_sw used to check whether two vectors have overlap
 *
 ************************************************************************************************/

double comp_sw(vector<double_vector>& mat1, vector<double_vector>& mat2)
{
	if(mat1[0].size() != mat2[0].size())
	{
		cerr<<"Error: The two matrices are not equal in width!\n";
		exit(1);
	}

	int length = mat1[0].size();
	double sw=0;

	for(int j = 0; j < length; j++)
	{
		for(int i=0; i<4; i++)
		{
			sw+=(mat1[i][j] - mat2[i][j]) * 
				(mat1[i][j] - mat2[i][j]);
		}
	}

	sw/=length;
	sw=2-sw;

	return sw;
}

/*************************************************************************************************
 *
 * Function comp_overlap used to check whether two PSMs have overlap
 *
 ************************************************************************************************/

double comp_overlap(vector<int>& set1, vector<int>& set2)
{
	int flag=0;

	for(int i=0; i<set1.size(); i++)
	{
		if(find(set2.begin(), set2.end(), set1[i])
				!=set2.end() && set1[i]<top_num)
		{
			flag=1;
			break;
		}
	}

	return flag;
}

/*************************************************************************************************
 *
 * Function build_graph used to build similarity graph of PSMs
 *
 ************************************************************************************************/

void build_graph(vector<psm>& psm_set, vector<int_vector>& psm_nbr)
{
	vector<int> tmp_vec;

	for(int i=0; i<psm_set.size(); i++)
	{
		psm_nbr.push_back(tmp_vec);
	}

	for(int i=1; i<psm_set.size(); i++)
	{
		for(int j=0; j<i; j++)
		{
			double tmp_sw=comp_sw(psm_set[i].mat, psm_set[j].mat);
			if(tmp_sw>=sw_thr)
			{
				psm_nbr[i].push_back(j);
				psm_nbr[j].push_back(i);
			}
		}
	}

	cout<<"Finished building PSM Adjacency Graph."<<endl;
	cout<<"There're altogether "<<psm_nbr.size()<<" nodes in this graph."<<endl;
}

/************************************************************************************************
 *
 * Function psm2kmer used to transform PSM set into k-mer set
 *
 ************************************************************************************************/

void psm2kmer(vector<int>& tmp_kmer, vector<int>& tmp_psm, vector<psm>& all_psm, int kmer_num)
{
	tmp_kmer.clear();
	vector<int> flag;
	generate_flag(kmer_num, flag);

	for(int i=0;i<tmp_psm.size(); i++)
	{
		mask_kmer(all_psm[tmp_psm[i]].set, flag);
	}

	for(int i=0; i<kmer_num; i++)
	{
		if(flag[i]==1)
		{
			tmp_kmer.push_back(i);
		}
	}
}

/*************************************************************************************************
 *
 * Function comp_cover used to calculate the approximate coverage of the current k-mer set
 *
 ************************************************************************************************/

double comp_cover(vector<kmer_all>& kmer_final, vector<int>& tmp_set, int flag)
{
	int tmp_cover=0;

	if(flag==1)
	{
		for(int i=0; i<tmp_set.size(); i++)
		{
			tmp_cover+=kmer_final[tmp_set[i]].cover1;
		}
	}
	else if(flag==-1)
	{
		for(int i=0; i<tmp_set.size(); i++)
		{
			tmp_cover+=kmer_final[tmp_set[i]].cover2;
		}
	}

	return tmp_cover;
}

/*************************************************************************************************
 *
 * Function cover_psm used to compute the coverage of PSMs
 *
 ************************************************************************************************/

void cover_psm(vector<psm>& psm_set, vector<kmer_all>& kmer_final)
{
	for(int i=0; i<psm_set.size(); i++)
	{
		psm_set[i].cover1=comp_cover(kmer_final, psm_set[i].set, 1);
		psm_set[i].cover2=comp_cover(kmer_final, psm_set[i].set, -1);
	}

	cout<<"Finished cumputing the coverage for all PSMs."<<endl;
}

/*************************************************************************************************
 *
 * Function comp_occurr used to calculate the occurrence of the current k-mer set
 *
 ************************************************************************************************/

int comp_occurr(vector<kmer_all>& kmer_final, vector<int>& tmp_set)
{
	int tmp_occurr=0;

	for(int i=0; i<tmp_set.size(); i++)
	{
		tmp_occurr+=kmer_final[tmp_set[i]].occurr;
	}

	return tmp_occurr;
}

/*************************************************************************************************
 *
 * Function sw_col used to calculate the SW similarity score between two columns
 *
 ************************************************************************************************/

double sw_col(vector<double_vector>& mat1, vector<double_vector>& mat2, int col_id)
{
	double result=2;

	for(int i=0; i<4; i++)
	{
		result-=(mat1[i][col_id]-mat2[i][col_id])*(mat1[i][col_id]-mat2[i][col_id]);
	}

	return result;
}

/*************************************************************************************************
 *
 * Function sw_sim used to calculate the SW similarity scores
 *
 ************************************************************************************************/

double sw_sim(vector<double_vector>& mat1, vector<double_vector>& mat2)
{
	double result=0;

	for(int j=0; j<mat1[0].size(); j++)
	{
		result+=sw_col(mat1, mat2, j);
	}

	return result;
}

/*************************************************************************************************
 *
 * Function get_rand used to get one random index based on one distribution
 *
 ************************************************************************************************/

int get_rand(vector<double>& sim_vec)
{
	double* p;
	p=new double [sim_vec.size()];

	for(int i=0; i<sim_vec.size(); i++)
	{
		p[i]=sim_vec[i];
	}

	int result=genmulone(p, sim_vec.size());

	free_pt(p);

	return result;
}

/*************************************************************************************************
 *
 * Function sam_node used to choose the new node to initiate the Gibbs Sampling
 *
 ************************************************************************************************/

int sam_node(vector<int>& tmp_pre, vector<double_vector>& tmp_mat, vector<psm>& psm_set)
{
	int result;

	vector<double> sim_vec;	// vector to hold the similarity scores
	sim_vec.reserve(tmp_pre.size());

	for(int i=0; i<tmp_pre.size(); i++)
	{
		sim_vec.push_back(sw_sim(tmp_mat, psm_set[tmp_pre[i]].mat));
	}

	result=0;
	double max_sim=sim_vec[0];
	for(int i=1; i<sim_vec.size(); i++)
	{
		if(max_sim<sim_vec[i])
		{
			max_sim=sim_vec[i];
			result=i;
		}
	}

	return tmp_pre[result];
}

/*************************************************************************************************
 *
 * Function choose_node used to choose the old node to initiate the Gibbs Sampling
 *
 ************************************************************************************************/

int choose_node(vector<int>& tmp_pre)
{
	double* sam_vec;
	sam_vec=new double [tmp_pre.size()];

	for(int i=0; i<tmp_pre.size(); i++)
	{
		sam_vec[i]=1/(double)tmp_pre.size();
	}

	int res;
	res=genmulone(sam_vec, tmp_pre.size());
	res=tmp_pre[res];

	free_pt(sam_vec);
	return res;
}

/*************************************************************************************************
 *
 * Function get_nbr used to get the neighbor list of old node
 *
 ************************************************************************************************/

void get_nbr(int& old_node, vector<int>& psm_flag, vector<int>& tmp_nbr, vector<int_vector>& psm_nbr, vector<int>& tmp_pre)
{
	tmp_nbr.clear();

	for(int i=0; i<psm_nbr[old_node].size(); i++)
	{
		if(psm_flag[psm_nbr[old_node][i]]==0 && find(tmp_pre.begin(), tmp_pre.end(), psm_nbr[old_node][i])!=tmp_pre.end())
		{
			tmp_nbr.push_back(psm_nbr[old_node][i]);
		}
	}
}

/*************************************************************************************************
 *
 * Function comp_sc used to calculate the motif score of the current preliminary motif
 *
 ************************************************************************************************/

double comp_sc(vector<double_vector> mat, int& occurr, int& length)
{
	double sc=0;

	for(int i=0; i<4; i++)
	{
		for(int j=0; j<length; j++)
		{
			if(mat[i][j]==0)
			{
				mat[i][j]=0.00001;
			}

			mat[i][j]=mat[i][j]*log(mat[i][j]/nt_freq[i]);
			sc+=mat[i][j];
		}
	}

	sc/=length;
	sc=exp(sc);
	sc=sc*occurr;

	return sc;
}

/*************************************************************************************************
 *
 * Function del_element used to delete element in vector
 *
 ************************************************************************************************/

void del_element(vector<int>& tmp_vec, int& val)
{
	for(vector<int>::iterator i=tmp_vec.begin(); i!=tmp_vec.end(); i++)
	{
		if(*i==val)
		{
			tmp_vec.erase(i);
			break;
		}
	}
}

/*************************************************************************************************
 *
 * Function if_accept used to check whether we add one node to the current preliminary motif
 *
 ************************************************************************************************/

int if_accept(vector<int>& tmp_pre, int& tmp_occurr, vector<double_vector>& tmp_mat, int& old_node, int& new_node, vector<kmer_all>& kmer_final, vector<psm>& psm_set, int seq_num)
{
	int flag=0;

	vector<int> old_pre=tmp_pre;
	old_pre.push_back(old_node);
	vector<int> old_kmer;
	psm2kmer(old_kmer, old_pre, psm_set, kmer_final.size());
	vector<double_vector> old_mat;
	int old_occurr=comp_occurr(kmer_final, old_kmer);
	comp_mat(old_mat, old_kmer, kmer_final, kmer_length);
	norm_mat(old_mat, old_occurr, kmer_length);
	double old_score=comp_sc(old_mat, old_occurr, kmer_length);

	vector<int> new_pre=old_pre;
	new_pre.push_back(old_node);
	new_pre.push_back(new_node);
	vector<int> new_kmer;
	psm2kmer(new_kmer, new_pre, psm_set, kmer_final.size());
	int new_occurr=comp_occurr(kmer_final, new_kmer);
	vector<double_vector> new_mat;
	comp_mat(new_mat, new_kmer, kmer_final, kmer_length);
	norm_mat(new_mat, new_occurr, kmer_length);
	double new_score=comp_sc(new_mat, new_occurr, kmer_length);

	vector<int> del_pre=old_pre;
	del_pre.push_back(new_node);
	vector<int> del_kmer;
	psm2kmer(del_kmer, del_pre, psm_set, kmer_final.size());
	int del_occurr=comp_occurr(kmer_final, del_kmer);
	vector<double_vector> del_mat;
	comp_mat(del_mat, del_kmer, kmer_final, kmer_length);
	norm_mat(del_mat, del_occurr, kmer_length);
	double del_score=comp_sc(del_mat, del_occurr, kmer_length);

	if(new_score>old_score && new_score>del_score)
	{
		flag=1;
	}
	else if(del_score>old_score)
	{
		flag=-1;
	}

	return flag;
}

/*************************************************************************************************
 *
 * Function psm2pre used to transform PSMs into preliminary motifs
 *
 ************************************************************************************************/

void psm2pre(vector<int_vector>& pre_out, vector<psm>& psm_set)
{
	pre_out.clear();

	for(int i=0; i<psm_set.size(); i++)
	{
		pre_out.push_back(psm_set[i].set);
	}
}

/*************************************************************************************************
 *
 * Function gibbs_sam used to perform Gibbs Sampling
 *
 ************************************************************************************************/

void gibbs_sam(vector<int_vector>& pre_out, vector<psm>& psm_set, vector<kmer_all>& kmer_final, int& num_pre, int& num_iter, vector<int_vector>& psm_nbr, int seq_num)
{
	vector<int> psm_flag;
	generate_flag(psm_set.size(), psm_flag);
	int seed_psm;
	vector<int> tmp_pre, tmp_kmer, tmp_nbr;
	vector<double_vector> tmp_mat;
	int tmp_occurr, old_node, new_node, del_node;
	double tmp_score, tmp_cover1, tmp_cover2;
	int sam_flag;

	cout<<"Begin Gibbs Sampling ..."<<endl;

	for(int i=1; i<=num_pre; i++)
	{
		seed_psm=find_seed(psm_flag);

		if(seed_psm==-1)
		{
			break;
		}

		tmp_pre.clear();
		tmp_pre.push_back(seed_psm);
		for(int j=0; j<psm_nbr[seed_psm].size(); j++)
		{
			if(psm_flag[psm_nbr[seed_psm][j]]==0)
			{
				tmp_pre.push_back(psm_nbr[seed_psm][j]);
			}
		}
		mask_kmer(tmp_pre, psm_flag);
		psm2kmer(tmp_kmer, tmp_pre, psm_set, kmer_final.size());

		if(tmp_pre.size()==1)
		{
			pre_out.push_back(tmp_kmer);
			continue;
		}

		for(int j=1; j<=num_iter; j++)
		{
			old_node=choose_node(tmp_pre);
			del_element(tmp_pre, old_node);
			psm_flag[old_node]=0;
			psm2kmer(tmp_kmer, tmp_pre, psm_set, kmer_final.size());
			tmp_occurr=comp_occurr(kmer_final, tmp_kmer);
			comp_mat(tmp_mat, tmp_kmer, kmer_final, kmer_length);
			norm_mat(tmp_mat, tmp_occurr, kmer_length);
			tmp_score=comp_sc(tmp_mat, tmp_occurr, kmer_length);
			get_nbr(old_node, psm_flag, tmp_nbr, psm_nbr, tmp_pre);

			if(tmp_nbr.size()==0)
			{
				psm_flag[old_node]=1;
				tmp_pre.push_back(old_node);
				continue;
			}

			new_node=sam_node(tmp_nbr, tmp_mat, psm_set);

			sam_flag=if_accept(tmp_pre, tmp_occurr, tmp_mat, old_node, new_node, kmer_final, psm_set, seq_num);
			
			if(sam_flag==1)
			{
				tmp_pre.push_back(old_node);
				tmp_pre.push_back(new_node);
			}
			else if(sam_flag==-1)
			{
				tmp_pre.push_back(new_node);
			}
			else
			{
				tmp_pre.push_back(old_node);
			}

			mask_kmer(tmp_pre, psm_flag);
		}

		pre_out.push_back(tmp_kmer);
	}

	cout<<"Finished Gibbs Sampling."<<endl<<"We have obtained altogether "<<pre_out.size()<<" preliminary motifs."<<endl;
}

/*************************************************************************************************
 *
 * Function build_flank used to build flanking matrices
 *
 ************************************************************************************************/

void build_flank(vector<int>& tmp_set, vector<kmer_all>& kmer_final, vector<double_vector>& flank, int direct, int length)
{
	init_mat(flank, length);

	for(int i=0; i<tmp_set.size(); i++)
	{
		if(direct==-1)
		{
			for(int j=0; j<4; j++)
			{
				for(int k=0; k<length; k++)
				{
					flank[j][k]+=kmer_final[tmp_set[i]].left[j][k];
				}
			}
		}
		else
		{
			for(int j=0; j<4; j++)
			{
				for(int k=0; k<length; k++)
				{
					flank[j][k]+=kmer_final[tmp_set[i]].right[j][k];
				}
			}
		}
	}
}

/*************************************************************************************************
 *
 * Function site_pre used to combine the site information of all k-mers contained
 *
 ************************************************************************************************/

void site_pre(pre_mtf& tmp_pre, vector<kmer_all>& kmer_final)
{
	tmp_pre.site.clear();
	pair<int, int> tmp_pair;
	map<pair<int, int>, int> site_map;

	for(int i=0; i<tmp_pre.set.size(); i++)
	{
		for(int j=0; j<kmer_final[tmp_pre.set[i]].site.size(); j+=2)
		{
			tmp_pair=make_pair(kmer_final[tmp_pre.set[i]].site[j], kmer_final[tmp_pre.set[i]].site[j+1]);
			site_map[tmp_pair]=1;
		}
	}

	for(map<pair<int, int>, int>::iterator it=site_map.begin(); it!=site_map.end(); it++)
	{
		tmp_pre.site.push_back((it->first).first);
		tmp_pre.site.push_back((it->first).second);
	}
}

/*************************************************************************************************
 *
 * Function get_pre used to get the set of preliminary motifs based on preliminary output from Gibbs Sampling
 *
 ************************************************************************************************/

void get_pre(vector<pre_mtf>& all_pre, vector<int_vector>& pre_out, vector<kmer_all>& kmer_final, int seq_num)
{
	for(int i=0; i<pre_out.size(); i++)
	{
		pre_mtf tmp_pre;
		
		tmp_pre.set=pre_out[i];
		site_pre(tmp_pre, kmer_final);
		tmp_pre.occurr=comp_occurr(kmer_final, tmp_pre.set);
		comp_mat(tmp_pre.mat, tmp_pre.set, kmer_final, kmer_length);
		norm_mat(tmp_pre.mat, tmp_pre.occurr, kmer_length);
		build_flank(tmp_pre.set, kmer_final, tmp_pre.left, -1, lmer_length);
		build_flank(tmp_pre.set, kmer_final, tmp_pre.right, 1, lmer_length);
		norm_mat(tmp_pre.left, tmp_pre.occurr, lmer_length);
		norm_mat(tmp_pre.right, tmp_pre.occurr, lmer_length);
		tmp_pre.cover1=comp_cover(kmer_final, tmp_pre.set, 1);
		tmp_pre.cover2=comp_cover(kmer_final, tmp_pre.set, -1);
		tmp_pre.score=ztest(tmp_pre.cover1, tmp_pre.cover2, sum_exp, sum_bg);

		all_pre.push_back(tmp_pre);
	}
}

/*************************************************************************************************
 *
 * Function test_cell used to check one cell in one column (Two Proportion z-test)
 *
 ************************************************************************************************/

double test_cell(double this_val, double that_val, int occurr)
{
	double pos_occurr=occurr*this_val;
	double neg_occurr=occurr*that_val;
	double p=(pos_occurr+neg_occurr)/(2*occurr);
	double z=fabs((this_val-that_val)/sqrt(p*(1-p)*(2/(double)occurr)));
	
	return z;
}

/*************************************************************************************************
 *
 * Function test_col used to check one column (Two Proportion z-test)
 *
 ************************************************************************************************/

double test_col(vector<double_vector>& flank, int col_id, int occurr)
{
	double max_z=0;
	double tmp_z;

	for(int i=0; i<4; i++)
	{
		tmp_z=test_cell(flank[i][col_id], nt_freq[i], occurr);

		if(tmp_z>max_z)
		{
			max_z=tmp_z;
		}
	}

	return max_z;
}

/*************************************************************************************************
 *
 * Function refine_one used to refine one preliminary motif
 *
 ************************************************************************************************/

void refine_one(pre_mtf& one_pre)
{
	one_pre.begin=lmer_length-1;

	for(int i=lmer_length-1; i>=0; i--)
	{
		if(test_col(one_pre.left, i, one_pre.occurr)<thr2)
		{
			one_pre.begin=i+1;
			break;
		}
	}

	one_pre.end=0;

	for(int i=0; i<lmer_length; i++)
	{
		if(test_col(one_pre.right, i, one_pre.occurr)<thr2)
		{
			one_pre.end=i-1;
			break;
		}
	}
}

/*************************************************************************************************
 *
 * Function refine_mtf used to refine the preliminary motifs
 *
 ************************************************************************************************/

void refine_mtf(vector<pre_mtf>& all_pre)
{
	for(int i=0; i<all_pre.size(); i++)
	{
		refine_one(all_pre[i]);
	}
}

/*************************************************************************************************
 *
 * Function cut_mat used to transform matrices
 *
 ************************************************************************************************/

void cut_mat(pre_mtf& tmp_pre, vector<double_vector>& mat)
{
	mat.clear();
	deque<double> tmp_ln;
	vector<double> tmp_vec;

	for(int i=0; i<4; i++)
	{
		tmp_ln.clear();
		tmp_vec.clear();

		for(int j=0; j<kmer_length; j++)
		{
			tmp_ln.push_back(tmp_pre.mat[i][j]);
		}

		if(lmer_length > 0)
		{
			if(tmp_pre.end>=0)
			{
				for(int j=0; j<=tmp_pre.end; j++)
				{
					tmp_ln.push_back(tmp_pre.right[i][j]);
				}
			}
	
			if(tmp_pre.begin<lmer_length)
			{
				for(int j=lmer_length-1; j>=tmp_pre.begin; j--)
				{
					tmp_ln.push_front(tmp_pre.left[i][j]);
				}
			}
		}

		for(deque<double>::iterator i=tmp_ln.begin(); i!=tmp_ln.end(); i++)
		{
			tmp_vec.push_back(*i);
		}

		mat.push_back(tmp_vec);
	}
}

/*************************************************************************************************
 *
 * Function make_wild used to make hash table of wild cards
 *
 ************************************************************************************************/

void make_wild(char* wild_card, char* reverse_wild)
{
	wild_card[0]='N';
	reverse_wild[0]='N';
	wild_card[1]='A';
	reverse_wild[1]='T';
	wild_card[2]='C';
	reverse_wild[2]='G';
	wild_card[3]='M';	// A, C
	reverse_wild[3]='K';
	wild_card[4]='G';
	reverse_wild[4]='C';
	wild_card[5]='R';	// A, G
	reverse_wild[5]='Y';
	wild_card[6]='S';	// C, G
	reverse_wild[6]='S';
	wild_card[7]='V';	// A, C, G
	reverse_wild[7]='B';
	wild_card[8]='T';
	reverse_wild[8]='A';
	wild_card[9]='W';	// A, T
	reverse_wild[9]='W';
	wild_card[10]='Y';	// C, T
	reverse_wild[10]='R';
	wild_card[11]='H';	// A, C, T
	reverse_wild[11]='D';
	wild_card[12]='K';	// G, T
	reverse_wild[12]='M';
	wild_card[13]='D';	// A, G, T
	reverse_wild[13]='H';
	wild_card[14]='B';	// G, C, T
	reverse_wild[14]='V';

	cout<<"Finished constructing wild card tables."<<endl;
}

/*************************************************************************************************
 *
 * Function col_deg used to get the degenerate consensus string 
 *
 ************************************************************************************************/

void col_deg(string& deg, string& rev_deg, vector<double_vector>& mat, int& col_id)
{
	int sum=0;

	for(int i=0; i<4; i++)
	{
		if(mat[i][col_id]>0.25)
		{
			sum+=(int)(rint(pow(2, i)));
		}
	}

	deg[col_id]=wild_card[sum];
	rev_deg[rev_deg.length()-1-col_id]=reverse_wild[sum];
}

/*************************************************************************************************
 *
 * Function get_deg used to get the degenerate consensus strings
 *
 ************************************************************************************************/

void get_deg(string& deg, string& rev_deg, vector<double_vector>& mat)
{
	init_str(deg, mat[0].size());
	init_str(rev_deg, mat[0].size());

	for(int i=0; i<deg.length(); i++)
	{
		col_deg(deg, rev_deg, mat, i);
	}
}

/*************************************************************************************************
 *
 * Function build_rev used to get the reverse consensus string
 *
 ************************************************************************************************/

void build_rev(string& rev_cons, string& cons)
{
	init_str(rev_cons, cons.length());

	for(int i=0; i<cons.length(); i++)
	{
		rev_cons[cons.length()-1-i]=alphabet[3-r_alphabet[cons[i]]];
	}
}

/*************************************************************************************************
 *
 * Function build_mtf used to transform one preliminary motif into one motif
 *
 ************************************************************************************************/

void build_mtf(pre_mtf& tmp_pre, mtf& tmp_mtf)
{
	tmp_mtf.set=tmp_pre.set;
	tmp_mtf.nsites=tmp_pre.occurr;
	cut_mat(tmp_pre, tmp_mtf.mat);
	tmp_mtf.alength=tmp_mtf.mat[0].size();
	get_cons(tmp_mtf.cons, tmp_mtf.mat);
	get_deg(tmp_mtf.deg, tmp_mtf.rev_deg, tmp_mtf.mat);
	build_rev(tmp_mtf.rev_cons, tmp_mtf.cons);
	tmp_mtf.score=tmp_pre.score;
}

/*************************************************************************************************
 *
 * Function get_site used to get the sites of motif
 *
 ************************************************************************************************/

void get_site(pre_mtf& tmp_pre, mtf& tmp_mtf, sequence& seq_final)
{
	st tmp_st;

	if(str_flag==1)
	{
		for(int i=0; i<tmp_pre.site.size(); i+=2)
		{
			tmp_st.header=seq_final.name[tmp_pre.site[i]];
			tmp_st.strand='+';
			tmp_st.begin=tmp_pre.site[i+1]-lmer_length+tmp_pre.begin;
			tmp_st.end=tmp_pre.site[i+1]+kmer_length+tmp_pre.end;

			tmp_mtf.site.push_back(tmp_st);
		}
	}
	else
	{
		for(int i=0; i<tmp_pre.site.size(); i+=2)
		{
			tmp_st.header=seq_final.name[tmp_pre.site[i]/2];
			
			if(tmp_pre.site[i]%2==0)
			{
				tmp_st.strand='+';
				tmp_st.begin=tmp_pre.site[i+1]-lmer_length+tmp_pre.begin;
				tmp_st.end=tmp_pre.site[i+1]+kmer_length+tmp_pre.end;
			}
			else
			{
				tmp_st.strand='-';
				tmp_st.begin=tmp_pre.site[i+1]-lmer_length+tmp_pre.begin;
				tmp_st.end=tmp_pre.site[i+1]+kmer_length-1+tmp_pre.end;
				int tmp_val=tmp_st.begin;
				tmp_st.begin=seq_final.strand[tmp_pre.site[i]].size()-tmp_st.end-2;
				tmp_st.end=seq_final.strand[tmp_pre.site[i]].size()-tmp_val;
			}

			tmp_mtf.site.push_back(tmp_st);
		}
	}
}

/*************************************************************************************************
 *
 * Function pre2mtf used to transform preliminary motifs into motifs
 *
 ************************************************************************************************/

void pre2mtf(vector<pre_mtf>& all_pre, vector<mtf>& all_mtf, sequence& seq_final)
{
	for(int i=0; i<all_pre.size(); i++)
	{
		mtf tmp_mtf;
		build_mtf(all_pre[i], tmp_mtf);
		get_site(all_pre[i], tmp_mtf, seq_final);
		all_mtf.push_back(tmp_mtf);
	}

	cout<<"Finished transforming preliminary motifs into motifs."<<endl;
}

/*************************************************************************************************
 *
 * Function sort_mtf used to sort all the motifs
 *
 ************************************************************************************************/

void sort_mtf(vector<mtf>& mtf_set)
{
		double *mtf_scores;
		int *mtf_id1;
		int num=mtf_set.size();
		mtf_scores=new double [num];
		mtf_id1=new int [num];

		int i;

		for(i=0; i<num; i++)
		{
				mtf_scores[i]=mtf_set[i].score;
				mtf_id1[i]=i;
		}

		quickSort(mtf_scores, 0, num-1, mtf_id1);
		reverse_sort(mtf_id1, num);

		vector<mtf> tmp_mtf;
		for(i=0; i<num; i++)
		{
			if(!last_trivial(mtf_set[mtf_id1[i]].cons))
			{
				continue;
			}

			tmp_mtf.push_back(mtf_set[mtf_id1[i]]);
		}

		mtf_set=tmp_mtf;

		delete [] mtf_id1;
		delete [] mtf_scores;

		cout<<"Finished sorting the motifs according to motif scores."<<endl;
		cout<<"Finished kicking out the trivial motifs."<<endl<<"There're "<<mtf_set.size()<<" motifs left."<<endl;
}

/*************************************************************************************************
 *
 * Function str2vec used to transform strings into vectors
 *
 ************************************************************************************************/

void str2vec(string& str, vector<char_vector>& vec)
{
	vec.clear();
	vector<char> single_vec;

	for(int i=0; i<str.length(); i++)
	{
		single_vec.clear();

		if(str[i]=='A')
		{
			single_vec.push_back('A');
		}
		else if(str[i]=='C')
		{
			single_vec.push_back('C');
		}
		else if(str[i]=='M')
		{
			single_vec.push_back('A');
			single_vec.push_back('C');
		}
		else if(str[i]=='G')
		{
			single_vec.push_back('G');
		}
		else if(str[i]=='R')
		{
			single_vec.push_back('A');
			single_vec.push_back('G');
		}
		else if(str[i]=='S')
		{
			single_vec.push_back('C');
			single_vec.push_back('G');
		}
		else if(str[i]=='V')
		{
			single_vec.push_back('A');
			single_vec.push_back('C');
			single_vec.push_back('G');
		}
		else if(str[i]=='T')
		{
			single_vec.push_back('T');
		}
		else if(str[i]=='W')
		{
			single_vec.push_back('A');
			single_vec.push_back('T');
		}
		else if(str[i]=='Y')
		{
			single_vec.push_back('C');
			single_vec.push_back('T');
		}
		else if(str[i]=='H')
		{
			single_vec.push_back('A');
			single_vec.push_back('C');
			single_vec.push_back('T');
		}
		else if(str[i]=='K')
		{
			single_vec.push_back('G');
			single_vec.push_back('T');
		}
		else if(str[i]=='D')
		{
			single_vec.push_back('A');
			single_vec.push_back('G');
			single_vec.push_back('T');
		}
		else if(str[i]=='B')
		{
			single_vec.push_back('G');
			single_vec.push_back('C');
			single_vec.push_back('T');
		}
		else
		{
			single_vec.push_back('A');
			single_vec.push_back('C');
			single_vec.push_back('G');
			single_vec.push_back('T');
		}

		vec.push_back(single_vec);
	}
}

/*************************************************************************************************
 *
 * Function eval_hd used to calculate similarity between motifs of the same length
 *
 ************************************************************************************************/

int eval_hd(string str1, string str2)
{
	if(str1.length()!=str2.length())
	{
		cerr<<"Error: The lengths of the two strings are not equal. Please check the details.\n";
		exit(1);
	}

	vector<char_vector> str_vec1, str_vec2;
	str2vec(str1, str_vec1);
	str2vec(str2, str_vec2);

	int dist=0;

	for(int i=0; i<str_vec1.size(); i++)
	{
		int dt=1;

		for(int j=0; j<str_vec1[i].size(); j++)
		{
			if(find(str_vec2[i].begin(), str_vec2[i].end(), str_vec1[i][j])!=str_vec2[i].end())
			{
				dt=0;
				break;
			}
		}

		dist+=dt;
	}

	return dist;
}

/*************************************************************************************************
 *
 * Function cmp_mtf used to determine the similarity between two motifs in slack conditions
 *
 ************************************************************************************************/

int cmp_mtf(mtf& mtf1, mtf& mtf2)
{
	int length;
	if(mtf1.alength >= mtf2.alength)
	{
		length=mtf2.alength;
	}
	else
	{
		length=mtf1.alength;
	}
	int min_val=length;
	int flag;
	int tmp_val;

	for(int i=0; i<=mtf1.alength-length; i++)
	{
		for(int j=0; j<=mtf2.alength-length; j++)
		{
			tmp_val=eval_hd(mtf1.deg.substr(i, length), mtf2.deg.substr(j, length));

			if(tmp_val<min_val)
			{
				min_val=tmp_val;
			}

			tmp_val=eval_hd(mtf1.deg.substr(i, length), mtf2.rev_deg.substr(j, length));

			if(tmp_val<min_val)
			{
				min_val=tmp_val;
			}
		}
	}

	if(min_val>=redundant_thr)
	{
		flag=0;
	}
	else
	{
		flag=1;
	}

	return flag;
}



/*************************************************************************************************
 *
 * Function sift_mtf used to delete the similar motifs with lower motif scores
 *
 ************************************************************************************************/

void sift_mtf(vector<mtf>& all_mtf)
{
	vector<int> flag;
	generate_flag(all_mtf.size(), flag);

	for(int i=0; i<all_mtf.size()-1; i++)
	{
		for(int j=i+1; j<all_mtf.size(); j++)
		{
			if(flag[j]==0 && cmp_mtf(all_mtf[i], all_mtf[j])==1)
			{
				flag[j]=1;
			}
		}
	}

	vector<mtf> tmp_all;

	for(int i=0; i<all_mtf.size(); i++)
	{
		if(flag[i]==0)
		{
			tmp_all.push_back(all_mtf[i]);
		}
	}

	all_mtf=tmp_all;

	cout<<"Finished deleting similar motifs with lower motif scores."<<endl<<"There are altogether "<<all_mtf.size()<<" motifs left."<<endl;
}

/*************************************************************************************************
 *
 * Function print_mtf used to print the result into one file
 *
 ************************************************************************************************/

void print_mtf(char *in_file, char *bg_file, char *out_file, vector<mtf>& all_mtf)
{
	string tmp_out=out_file;
	tmp_out+=".meme";
	ofstream f_out_op(tmp_out.c_str());

	if(!f_out_op)
	{
		cerr<<"Error: Can't open file "<<tmp_out.c_str()<<" for output!"<<endl;
		exit(1);
	}

	f_out_op<<"# MEME 4.0.0"<<endl<<"# Command: ./ProSampler -i "<<in_file<<" -b "<<bg_file<<" -o "<<out_file<<" -d "<<num_deg<<" -m "<<num_mtf<<" -f "<<num_iter<<" -k "<<kmer_length<<" -l "<<lmer_length<<" -r "<<redundant_thr<<" -p "<<str_flag<<" -t "<<thr1<<" -c "<<hd_thr<<" -z "<<thr2<<" -h "<<help_flag<<endl;
	f_out_op<<endl<<"# Begin: "<<begin_pkg<<endl;
	f_out_op<<"#   End: "<<end_pkg<<endl<<endl;
	f_out_op<<"MEME Version 4"<<endl<<endl;
	f_out_op<<"ALPHABET= ACGT"<<endl<<endl;

	if(str_flag==1)
	{
		f_out_op<<"Strands: +"<<endl<<endl;
	}
	else
	{
		f_out_op<<"Strands: + -"<<endl<<endl;
	}

	f_out_op<<"Background letter frequencies (from dataset):"<<endl;
	f_out_op.setf(ios::fixed);

	for(int i=0; i<3; i++)
	{
		f_out_op<<alphabet[i]<<" "<<fixed<<setprecision(PRECISE)<<nt_freq[i]<<" ";
	}
	f_out_op<<alphabet[3]<<" "<<fixed<<setprecision(PRECISE)<<nt_freq[3]<<endl<<endl;

	if(num_mtf>all_mtf.size())
	{
		num_mtf=all_mtf.size();
	}

	for(int i=0; i<num_mtf; i++)
	{
		f_out_op<<"MOTIF "<<all_mtf[i].deg<<" "
			<<all_mtf[i].rev_deg<<" ProSampler"<<endl<<endl;
		f_out_op<<"letter-probability matrix: alength= 4 w= "
			<<all_mtf[i].alength<<" nsites= "<<all_mtf[i].nsites
			<<" score= "<<all_mtf[i].score<<endl;

		for(int j=0; j<all_mtf[i].alength; j++)
		{
			f_out_op.setf(ios::fixed);
			for(int k=0; k<3; k++)
			{
				f_out_op<<fixed<<setprecision(PRECISE)<<all_mtf[i].mat[k][j]<<" ";
			}
			f_out_op<<fixed<<setprecision(PRECISE)<<all_mtf[i].mat[3][j]<<endl;
		}

		f_out_op<<endl<<endl;
	}

	f_out_op<<endl;
	f_out_op.unsetf(ios::fixed);
	f_out_op<<"Time "<<difftime(end_t, begin_t)<<" secs."<<endl;
	f_out_op.close();

	cout<<"Finished generating the motif file "<<tmp_out<<"."<<endl;
	cout<<"There're altogether "<<num_mtf<<" motifs output."<<endl;
}

/*************************************************************************************************
 *
 * Function print_site used to print the result into one file
 *
 ************************************************************************************************/

void print_site(char *in_file, char *bg_file, char *out_file, vector<mtf>& all_mtf)
{
	string tmp_out=out_file;
	tmp_out+=".site";
	ofstream f_out_op(tmp_out.c_str());

	if(!f_out_op)
	{
		cerr<<"Error: Can't open file "<<tmp_out.c_str()<<" for output!"<<endl;
		exit(1);
	}

	f_out_op<<"# ProSampler 1.0.0"<<endl<<"# Command: ./ProSampler -i "<<in_file<<" -b "<<bg_file<<" -o "<<out_file<<" -d "<<num_deg<<" -m "<<num_mtf<<" -f "<<num_iter<<" -k "<<kmer_length<<" -l "<<lmer_length<<" -r "<<redundant_thr<<" -p "<<str_flag<<" -t "<<thr1<<" -c "<<hd_thr<<" -z "<<thr2<<" -h "<<help_flag<<endl;
	f_out_op<<endl<<"# Begin: "<<begin_pkg<<endl;
	f_out_op<<"#   End: "<<end_pkg<<endl<<endl;
	f_out_op<<"ProSampler Version 1.0.0"<<endl<<endl;
	f_out_op<<"ALPHABET= ACGT"<<endl<<endl;

	if(str_flag==1)
	{
		f_out_op<<"Strands: +"<<endl<<endl;
	}
	else
	{
		f_out_op<<"Strands: + -"<<endl<<endl;
	}

	f_out_op<<"Background letter frequencies (from dataset):"<<endl;
	
	if(num_mtf>all_mtf.size())
	{
		num_mtf=all_mtf.size();
	}

	for(int i=0; i<num_mtf; i++)
	{
		f_out_op<<"MOTIF "<<all_mtf[i].deg<<" "<<all_mtf[i].rev_deg<<" ProSampler"<<endl<<endl;
		f_out_op<<"letter-probability matrix: alength= 4 w= "<<all_mtf[i].alength<<" nsites= "<<all_mtf[i].nsites<<" score= "<<all_mtf[i].score<<endl<<endl<<"********************"<<endl<<endl;

		for(int j=0; j<all_mtf[i].site.size(); j++)
		{
			f_out_op<<all_mtf[i].site[j].header<<"\t"<<all_mtf[i].site[j].strand<<"\t"<<all_mtf[i].site[j].begin<<"\t"<<all_mtf[i].site[j].end<<endl;
		}

		f_out_op<<endl<<endl;
	}

	f_out_op<<endl;

	f_out_op<<"Time "<<difftime(end_t, begin_t)<<" secs."<<endl;
	f_out_op.close();

	cout<<"Finished generating the motif file "<<tmp_out<<"."<<endl;
	cout<<"There're altogether "<<num_mtf<<" motifs output."<<endl;
	cout<<"Thank you for using ProSampler!"<<endl;
}

/*************************************************************************************************
 *
 * Function get_spic used to get SPIC format output file from motif
 *
 ************************************************************************************************/

void get_spic(vector<mtf>& all_mtf, vector<spic>& all_spic)
{
	spic tmp_spic;

	for(int i=0; i<all_mtf.size(); i++)
	{
		tmp_spic.pfm=all_mtf[i].mat;
		tmp_spic.pssm=all_mtf[i].mat;
		
		for(int j=0; j<4; j++)
		{
			for(int k=0; k<all_mtf[i].alength; k++)
			{
				tmp_spic.pfm[j][k]*=all_mtf[i].nsites;

				if(tmp_spic.pssm[j][k]==0)
				{
					tmp_spic.pssm[j][k]=0.00001;
				}

				tmp_spic.pssm[j][k]/=nt_freq[j];
				tmp_spic.pssm[j][k]=log(tmp_spic.pssm[j][k]);
			}
		}

		tmp_spic.ic.clear();

		for(int j=0; j<all_mtf[i].alength; j++)
		{
			double tmp_sum=0;

			for(int k=0; k<4; k++)
			{
				tmp_sum+=all_mtf[i].mat[k][j]*tmp_spic.pssm[k][j];
			}

			tmp_spic.ic.push_back(tmp_sum);
		}

		all_spic.push_back(tmp_spic);
	}

	cout<<"Finished transforming motifs into SPIC format."<<endl;
}

/*************************************************************************************************
 *
 * Function print_spic used to print the result into one file
 *
 ************************************************************************************************/

void print_spic(char *in_file, char *bg_file, char *out_file, vector<spic>& all_spic, vector<mtf>& all_mtf)
{
	string tmp_out=out_file;
	tmp_out+=".spic";
	ofstream f_out_op(tmp_out.c_str());

	if(!f_out_op)
	{
		cerr<<"Error: Can't open file "<<tmp_out.c_str()<<" for output!"<<endl;
		exit(1);
	}

	f_out_op<<"# ProSampler 1.0.0"<<endl<<"# Command: ./ProSampler -i "<<in_file<<" -b "<<bg_file<<" -o "<<out_file<<" -d "<<num_deg<<" -m "<<num_mtf<<" -f "<<num_iter<<" -k "<<kmer_length<<" -l "<<lmer_length<<" -r "<<redundant_thr<<" -p "<<str_flag<<" -t "<<thr1<<" -c "<<hd_thr<<" -z "<<thr2<<" -h "<<help_flag<<endl;
	f_out_op<<endl<<"# Begin: "<<begin_pkg<<endl;
	f_out_op<<"#   End: "<<end_pkg<<endl<<endl;
	f_out_op<<"ProSampler Version 1.0.0"<<endl<<endl;
	f_out_op<<"ALPHABET= ACGT"<<endl<<endl;

	if(str_flag==1)
	{
		f_out_op<<"Strands: +"<<endl<<endl;
	}
	else
	{
		f_out_op<<"Strands: + -"<<endl<<endl;
	}

	f_out_op<<"Background letter frequencies (from dataset):"<<endl;
	
	if(num_mtf>all_spic.size())
	{
		num_mtf=all_spic.size();
	}

	for(int i=0; i<num_mtf; i++)
	{
		f_out_op<<"MOTIF "<<all_mtf[i].deg<<" "<<all_mtf[i].rev_deg<<" ProSampler"<<endl<<endl;
		
		for(int j=0; j<4; j++)
		{
			f_out_op<<alphabet[j]<<"\t";
			
			for(int k=0; k<all_mtf[i].alength-1; k++)
			{
				f_out_op<<setiosflags(ios::fixed)<<setprecision(PRECISE);
				f_out_op<<setw(6)<<all_spic[i].pssm[j][k]<<"\t";
			}
			f_out_op<<setiosflags(ios::fixed)<<setprecision(PRECISE);
			f_out_op<<setw(6)<<all_spic[i].pssm[j][all_mtf[i].alength-1]<<endl;
		}
		
		f_out_op<<"I"<<"\t";
		f_out_op.setf(ios::fixed);

		for(int k=0; k<all_mtf[i].alength-1; k++)
		{
			f_out_op<<fixed<<setprecision(PRECISE);
			f_out_op<<setw(6)<<all_spic[i].ic[k]<<"\t";
		}
		f_out_op<<fixed<<setprecision(PRECISE);
		f_out_op<<setw(6)<<all_spic[i].ic[all_mtf[i].alength-1]<<endl;

		f_out_op.unsetf(ios::fixed);

		for(int j=0; j<4; j++)
		{
			char tmp_char;
			tmp_char=tolower(alphabet[j]);
			f_out_op<<tmp_char<<"\t";
			for(int k=0; k<all_mtf[i].alength-1; k++)
			{
				f_out_op<<int(all_spic[i].pfm[j][k])<<"\t";
			}
			f_out_op<<int(all_spic[i].pfm[j][all_mtf[i].alength-1])<<endl;
		}

		f_out_op<<endl;
	}

	f_out_op<<endl;

	f_out_op<<"Time "<<difftime(end_t, begin_t)<<" secs."<<endl;
	f_out_op.close();

	cout<<"Finished generating the motif file "<<tmp_out<<"."<<endl;
	cout<<"There're altogether "<<num_mtf<<" motifs output."<<endl;
	cout<<"Thank you for using ProSampler!"<<endl;
}

/*************************************************************************************************
 *
 * Main function
 *
 ************************************************************************************************/

 int main(int argc, char **argv)
 {
 	 begin_t=time(0);
	strftime(begin_pkg, sizeof(begin_pkg), 
			 "%b %d %Y %a %X %Z", localtime(&begin_t));

	parse_opt(argc, argv);

	if(help_flag==1)
	{
		usage();
	}

	r_alphabet['A']=0;
	r_alphabet['C']=1;
	r_alphabet['G']=2;
	r_alphabet['T']=3;

	sequence seq_nondeg, bg_nondeg;	// sequence with degenerate positions
	load_data(argv[f_in_id], seq_nondeg);
	load_data(argv[f_bg_id], bg_nondeg);
	de_lower(seq_nondeg);
	nt_stat(seq_nondeg, nt_freq);
	sequence seq_final;
	sequence bg_final;
	seq_generate(seq_nondeg, seq_final, str_flag);
	seq_generate(bg_nondeg, bg_final, str_flag);
	free_seq(seq_nondeg);
	free_seq(bg_nondeg);

	map<string, int_vector> kmer_site;
	kmer_count(kmer_site, seq_final, lmer_length);

	map<string, int_vector> kmer_bg;	// hold the k-mers in background sequences
	kmer_count(kmer_bg, bg_final, lmer_length);
	kmer_set major_set, minor_set;	// k-mer sets
	map<string, int> fa_flag;	
	// The flag to represent the status of k-mers in ChIP-seq data
	map<string, int> bg_flag;	// Status in background data
	for(map<string, int_vector>::iterator it=kmer_site.begin(); it!=kmer_site.end(); it++)
	{
		fa_flag[it->first]=1;
	}

	if(str_flag!=1)
	{
		comb_kmer(kmer_site, fa_flag, seq_final.strand, 
				kmer_bg, bg_flag, bg_final.strand);
	}
	choose_kmer(kmer_site, kmer_bg, major_set, 
			 seq_final.name.size(), fa_flag, minor_set);
	kmer_sort(major_set);
	kmer_sort(minor_set);
	kmer_site.clear();
	kmer_bg.clear();
	map<string, int_vector>().swap(kmer_site);
	map<string, int_vector>().swap(kmer_bg);
	free_seq(bg_nondeg);
	free_seq(bg_final);
	top_num=combine_major(major_set, minor_set);
	free_kmer(minor_set);
	vector<kmer_all> kmer_final;
	fill_kmer(major_set, kmer_final, seq_final.name.size(), seq_final);
	free_kmer(major_set);
	vector<psm> psm_set;
	kmer2psm(kmer_final, psm_set, top_num);
	fill_psm(psm_set, kmer_final, kmer_length);
	int seq_num=seq_final.name.size();
 	cover_psm(psm_set, kmer_final);
        test_psm(psm_set, sum_exp, sum_bg);
	comp_cons(psm_set);
	psm_sort(psm_set);
	vector<int_vector> pre_out;
	int num_pre;
	
	if(num_mtf>0)
	{
		 num_pre=MULTIPLE*num_mtf;
	}
	else
	{
		 num_pre=psm_set.size();
	}

	vector<int_vector> psm_nbr;
	build_graph(psm_set, psm_nbr);
	 gibbs_sam(pre_out, psm_set, kmer_final,
			 num_pre, num_iter, psm_nbr, seq_num);
	psm_set.clear();
	vector<psm>().swap(psm_set);
	psm_nbr.clear();
	vector<int_vector>().swap(psm_nbr);
	vector<pre_mtf> all_pre;
	get_pre(all_pre, pre_out, kmer_final, seq_num);
	kmer_final.clear();
	vector<kmer_all>().swap(kmer_final);
	pre_out.clear();
	vector<int_vector>().swap(pre_out);
	
	if(lmer_length > 0)
	{
		refine_mtf(all_pre);
	}

	make_wild(wild_card, reverse_wild);
	vector<mtf> all_mtf;
	pre2mtf(all_pre, all_mtf, seq_final);
	all_pre.clear();
	vector<pre_mtf>().swap(all_pre);
	sort_mtf(all_mtf);
	sift_mtf(all_mtf);

	end_t=time(0);
	strftime(end_pkg, sizeof(end_pkg), 
			 "%b %d %Y %a %X %Z", localtime(&end_t));
	print_mtf(argv[f_in_id], argv[f_bg_id], argv[f_out_id], all_mtf);
	print_site(argv[f_in_id], argv[f_bg_id], argv[f_out_id], all_mtf);
	vector<spic> all_spic;
	all_spic.reserve(all_mtf.size());
	get_spic(all_mtf, all_spic);
	print_spic(argv[f_in_id], argv[f_bg_id], argv[f_out_id], all_spic, all_mtf);

	return 0;
 }
